####################################################################
#
# �u���C�A���E�G���F���b�g�� �Γc��L ����
#
#       �wR��S-PLUS�ɂ�鑽�ϗʉ�́x
#
# �V���v�����K�[�E�W���p�� 2007�N
# ISBN �F 978-4-431-71312-8
#  http://www.springer.jp/japan/math/j71312.html
#
# http://biostatistics.iop.kcl.ac.uk/publications/everitt/
# An R and S-PlUS companion, Springer
#
#
#
####################################################################



##########################################################
#
#
#                          �� 1 ��
#                      ���ϗʃf�[�^�Ƒ��ϗʉ��
#
#
##########################################################


huswif<-source("Data/chap1huswif.dat")$value
# $value

head(huswif)

#
install.packages("xtable")
library(xtable)

xtable(huswif)
#
mean(huswif)
var(huswif)
sd(huswif)^2
#
#
xtable(var(huswif))
cor(huswif)
xtable(cor(huswif))
#
#
dis<-dist(huswif)
dis.matrix<-dist2full(dis)
round(dis.matrix,digits=2)
#
std<-sd(huswif);std
#
#
huswif.std<-sweep(huswif,2,std,FUN="/");huswif.std
dis<-dist(huswif.std)
dis.matrix<-dist2full(dis)
round(dis.matrix,digits=2)

1 - cor(huswif)
#
##load MASS library
#library(MASS)
##set seed for random number generation to get the same plots
#set.seed(1203)
#X<-mvrnorm(200,mu=c(0,0),Sigma=matrix(c(1,0.5,0.5,1.0),ncol=2))
##
## #
## par(mfrow=c(1,2))
## qqnorm(X[,1],ylab="Ordered observations")
## qqline(X[,1])
## qqnorm(X[,2],ylab="Ordered observations")
## qqline(X[,2])

#################################
options(X11fonts = c("-alias-mincho-%s-%s-*-*-%d-*-*-*-*-*-*-*","-adobe-symbol-*-*-*-*-%d-*-*-*-*-*-*-*"))
 ps.options(family= "Japan1Ryumin") # Windows �ł͂����������s


#load MASS library
library(MASS)
#set seed for random number generation to get the same plots
set.seed(1203)
X<-mvrnorm(200,mu=c(0,0),Sigma=matrix(c(1,0.5,0.5,1.0),ncol=2))

par(mfrow=c(1,2))
qqnorm(X[,1],ylab="�����̊ϑ��l", xlab= "���_���ʓ_", main = "���K Q-Q �v���b�g")
qqline(X[,1])
qqnorm(X[,2],ylab="�����̊ϑ��l", xlab = "���_���ʓ_", main = "���K Q-Q �v���b�g")
qqline(X[,2])



##
pdf(file="figure1.1.jp2.pdf")
par(mfrow=c(1,2))
qqnorm(X[,1],ylab="�����̊ϑ��l", xlab= "���_���ʓ_", main = "���K Q-Q �v���b�g")
qqline(X[,1])
qqnorm(X[,2],ylab="�����̊ϑ��l", xlab = "���_���ʓ_", main = "���K Q-Q �v���b�g")
qqline(X[,2])

dev.off()
#
###################################
par(mfrow=c(1,1))
chisplot(X)    
####################################
par(mfrow=c(1,2))
qqnorm(log(abs(X[,1])),ylab="Ordered observations")
qqline(log(abs(X[,1])))
qqnorm(log(abs(X[,2])),ylab="Ordered observations")
qqline(log(abs(X[,2])))

#####
par(mfrow=c(1,2))
qqnorm(log(abs(X[,1])), ylab="�����̊ϑ��l", xlab= "���_���ʓ_", main = "���K Q-Q �v���b�g")
qqline(log(abs(X[,1])))
qqnorm(log(abs(X[,2])),ylab="�����̊ϑ��l", xlab= "���_���ʓ_", main = "���K Q-Q �v���b�g" )
qqline(log(abs(X[,2])))
#

###

par(mfrow=c(1,2))
qqnorm(log(abs(X[,1])), ylab="�����̊ϑ��l", xlab= "���_���ʓ_", main = "���K Q-Q �v���b�g")
qqline(log(abs(X[,1])))
qqnorm(log(abs(X[,2])),ylab="�����̊ϑ��l", xlab= "���_���ʓ_", main = "���K Q-Q �v���b�g" )
qqline(log(abs(X[,2])))

####################################
par(mfrow=c(1,1))
chisplot(log(abs(X)))
#######################################################3
dist2full<-function(dis) {
	n<-attr(dis,"Size")
	full<-matrix(0,n,n)
	full[lower.tri(full)]<-dis
	full+t(full)
}

chisplot <- function(x) {
    if (!is.matrix(x)) stop("x is not a matrix")

    ### determine dimensions
    n <- nrow(x)
    p <- ncol(x)
    #
    xbar <- apply(x, 2, mean)
    S <- var(x)
    S <- solve(S)
    index <- (1:n)/(n+1)
    #
    xcent <- t(t(x) - xbar)
    di <- apply(xcent, 1, function(x,S) x %*% S %*% x,S)
    #
    quant <- qchisq(index,p)
    plot(quant, sort(di), ylab = "Ordered distances",
         xlab = "Chi-square quantile", lwd=2,pch=1)
   
}
######### For Everitt
# ���� p.9 �̗ݐϕ��z�}���쐬����



## x <- seq(0, 1, 0.01)
#x <- rnorm(1000, mean = 0, sd = 2)
## xq <- qnorm(x[order(x)])
#xp <- pnorm(x[order(x)],  mean = 0, sd = 2) # �e x �̊m��
#x.p0.7 <- x[order(x)][which(xp >= 0.7 & xp <= 0.71)][1]
#x.p0.8 <- x[order(x)][which(xp >= 0.8 & xp <= 0.81)][1]
#x.p0.2 <- x[order(x)][which(xp >= 0.2 & xp <= 0.21)][1]

##x.p0.7 <-  xp[xp >= 0.7 & xp <= 0.71][1]


#y <-  rnorm(1000, mean = -1.5, sd = 2)
#yp <- pnorm(y[order(y)], mean = -1.5, sd = 2)

#y.p0.7 <-  y[order(y)][which(yp >= 0.7 & yp <= 0.71)][1]
#y.p0.8 <-  y[order(y)][which(yp >= 0.8 & yp <= 0.81)][1]
## y.q0.2 <-  y[order(y)][which(y >= x.p0.2 & y <= x.p0.2 + 0.1)][1]

#par.old <- par(mar=c(2,2,2,2))
##
####
#pdf("p9.pdf")
##
###############################
options(X11fonts = c("-alias-mincho-%s-%s-*-*-%d-*-*-*-*-*-*-*","-adobe-symbol-*-*-*-*-%d-*-*-*-*-*-*-*"))
 ps.options(family= "Japan1Ryumin") # Windows �ł͂����������s

####
# x <- seq(0, 1, 0.01)
x <- rnorm(1000, mean = 0, sd = 2)
# xq <- qnorm(x[order(x)])
xp <- pnorm(x[order(x)],  mean = 0, sd = 2) # �e x �̊m��
x.p0.7 <- x[order(x)][which(xp >= 0.7 & xp <= 0.71)][1]
x.p0.8 <- x[order(x)][which(xp >= 0.8 & xp <= 0.81)][1]
x.p0.2 <- x[order(x)][which(xp >= 0.2 & xp <= 0.21)][1]

#x.p0.7 <-  xp[xp >= 0.7 & xp <= 0.71][1]


y <-  rnorm(1000, mean = -1.5, sd = 2)
yp <- pnorm(y[order(y)], mean = -1.5, sd = 2)

y.p0.7 <-  y[order(y)][which(yp >= 0.7 & yp <= 0.71)][1]
y.p0.8 <-  y[order(y)][which(yp >= 0.8 & yp <= 0.81)][1]
par(mar=c(2,2,2,2))

plot(seq(-10, 10, 0.01), seq(0, 1, 0.0005), type = "n", axes =F, xlab = "", ylab = "", main = "Cumulative distribution function")

plot(seq(-10, 10, 0.01), seq(0, 1, 0.0005), type = "n", axes =F, xlab = "", ylab = "", main = "�ݐϕ��z�֐�")

lines(x[order(x)], xp, xlim=c(-10, 10), lwd = 3 )
lines(y[order(y)], yp,  xlim=c(-10, 10), lwd = 3 )

lines(c(-9,9), c(1,1))
lines(c(-9,-9), c(1,0))
lines(c(-9,9), c(0,0))
lines(c(9,9), c(1,0))

arrows(-9, 0.8, x.p0.8, 0.8, length = 0.2, lty = 2, lwd = 2)
arrows(-9, 0.8, y.p0.8, 0.8, length = 0.2, lty = 1, lwd = 2)
arrows( x.p0.8, 0.8,  x.p0.8, 0, length = 0.2, lty = 2, lwd = 2)
arrows(y.p0.8, 0.8, y.p0.8, 0, length = 0.2, lty = 1, lwd = 2)

text(3.8, 0.85, expression(paste("c.d.f ", F[x], "( )")), cex = 1.1)
text(-2.0, 0.85,  expression( paste("c.d.f ", F[y], "( )")      ), cex = 1.1)
text(-10, 0.8, "p", cex = 1.1)

text(x.p0.8+0.5, -.02, expression(q [x] (p)), cex = 1.1)
text(y.p0.8, -.02, expression(q [y] (p)), cex = 1.1)

arrows(x.p0.2, 0.0, x.p0.2, 0.2, length = 0.2, lty = 1, lwd = 2)
arrows(x.p0.2, 0.0, x.p0.2,  pnorm( x.p0.2, mean = -1.5, sd = 2), length = 0.2, lty = 2, lwd = 2)
arrows(x.p0.2, 0.2, -9, 0.2, length = 0.2, lty = 1, lwd = 2)
arrows(x.p0.2,  pnorm( x.p0.2, mean = -1.5, sd = 2)  , -9,  pnorm( x.p0.2, mean = -1.5, sd = 2), length = 0.2, lty = 2, lwd = 2)

text(x.p0.2, -.02, "q", cex = 1.1)
text(-10,  pnorm( x.p0.2, mean = -1.5, sd = 2)   , expression(p [x] (q)), cex = 1.1)
text(-10, 0.2, expression(p [y] (q)), cex = 1.1)

text(-10,0, "0", cex = 1.2)
text(-10,1, "1", cex = 1.2)




# x <- seq(0, 1, 0.01)
x <- rnorm(1000, mean = 0, sd = 2)
# xq <- qnorm(x[order(x)])
xp <- pnorm(x[order(x)],  mean = 0, sd = 2) # �e x �̊m��
x.p0.7 <- x[order(x)][which(xp >= 0.7 & xp <= 0.71)][1]
x.p0.8 <- x[order(x)][which(xp >= 0.8 & xp <= 0.81)][1]
x.p0.2 <- x[order(x)][which(xp >= 0.2 & xp <= 0.21)][1]

#x.p0.7 <-  xp[xp >= 0.7 & xp <= 0.71][1]


y <-  rnorm(1000, mean = -1.5, sd = 2)
yp <- pnorm(y[order(y)], mean = -1.5, sd = 2)

y.p0.7 <-  y[order(y)][which(yp >= 0.7 & yp <= 0.71)][1]
y.p0.8 <-  y[order(y)][which(yp >= 0.8 & yp <= 0.81)][1]
par(mar=c(2,2,2,2))


plot(seq(-10, 10, 0.01), seq(0, 1, 0.0005), type = "n", axes =F, xlab = "", ylab = "", main = "�ݐϕ��z�֐�")

lines(x[order(x)], xp, xlim=c(-10, 10), lwd = 3 )
lines(y[order(y)], yp,  xlim=c(-10, 10), lwd = 3 )

lines(c(-9,9), c(1,1))
lines(c(-9,-9), c(1,0))
lines(c(-9,9), c(0,0))
lines(c(9,9), c(1,0))

arrows(-9, 0.8, x.p0.8, 0.8, length = 0.2, lty = 2, lwd = 2)
arrows(-9, 0.8, y.p0.8, 0.8, length = 0.2, lty = 1, lwd = 2)
arrows( x.p0.8, 0.8,  x.p0.8, 0, length = 0.2, lty = 2, lwd = 2)
arrows(y.p0.8, 0.8, y.p0.8, 0, length = 0.2, lty = 1, lwd = 2)

text(3.8, 0.85, expression(paste("c.d.f ", F[x], "( )")), cex = 1.1)
text(-2.0, 0.85,  expression( paste("c.d.f ", F[y], "( )")      ), cex = 1.1)
text(-10, 0.8, "p", cex = 1.1)

text(x.p0.8+0.5, -.02, expression(q [x] (p)), cex = 1.1)
text(y.p0.8, -.02, expression(q [y] (p)), cex = 1.1)

arrows(x.p0.2, 0.0, x.p0.2, 0.2, length = 0.2, lty = 1, lwd = 2)
arrows(x.p0.2, 0.0, x.p0.2,  pnorm( x.p0.2, mean = -1.5, sd = 2), length = 0.2, lty = 2, lwd = 2)
arrows(x.p0.2, 0.2, -9, 0.2, length = 0.2, lty = 1, lwd = 2)
arrows(x.p0.2,  pnorm( x.p0.2, mean = -1.5, sd = 2)  , -9,  pnorm( x.p0.2, mean = -1.5, sd = 2), length = 0.2, lty = 2, lwd = 2)

text(x.p0.2, -.02, "q", cex = 1.1)
text(-10,  pnorm( x.p0.2, mean = -1.5, sd = 2)   , expression(p [x] (q)), cex = 1.1)
text(-10, 0.2, expression(p [y] (q)), cex = 1.1)

text(-10,0, "0", cex = 1.2)
text(-10,1, "1", cex = 1.2)

###





##########################################################
#
#
#                          �� 2 ��
#  
#               ���ϗʃf�[�^�̃O���t�B�b�N�X�\��
#
#
#
##########################################################


airpoll <- source("Data/chap2airpoll.dat")$value
#
#
attach(airpoll)
#
#
#
par(mfrow=c(2,2))
par(pty="s")

# plot(SO2,Mortality, pch=1,lwd=1)
plot(SO2,Mortality, pch=1)
title("(a)",lwd=2)

plot(SO2,Mortality, pch=1,lwd=1)
abline(lm(Mortality~SO2), lwd=1)
title("(b)",lwd=2)


airpoll1<-jitter(cbind(SO2,Mortality))
plot(airpoll1[,1],airpoll1[,2],xlab="SO2",ylab="Mortality",pch=1, lwd=1)
title("(c)",lwd=2)

plot(SO2,Mortality,pch=1, lwd=1)
rug(jitter(SO2),side=1)
rug(jitter(Mortality),side=2)
title("(d)",lwd=2)
#
#

#
#
names<-abbreviate(row.names(airpoll))
par(mfrow=c(1,1))
plot(SO2,Mortality,lwd=2,type="n")
text(SO2,Mortality,labels=names,lwd=2)

#
names<-abbreviate(row.names(airpoll))
par(mfrow=c(1,1))
plot(SO2,Mortality,lwd=1,type="n")
text(SO2,Mortality,labels=names,lwd=1)

#
par(fig=c(0,0.7,0,0.7))
plot(SO2,Mortality,lwd=1)
abline(lm(Mortality~SO2),lwd=2)
lines(lowess(SO2,Mortality),lwd=2)
par(fig=c(0,0.7,0.65,1),new=TRUE)
#
hist(SO2,lwd=1)
par(fig=c(0.65,1,0,0.7),new=TRUE)
boxplot(Mortality,lwd=2)
# ��Ɠ���
par(fig=c(0,0.7,0,0.7))
plot(SO2,Mortality)
abline(lm(Mortality~SO2))
lines(lowess(SO2,Mortality))
par(fig=c(0,0.7,0.65,1),new=TRUE)
#
hist(SO2)
par(fig=c(0.65,1,0,0.7),new=TRUE)
boxplot(Mortality)

## par(fig=c(0.65,1,0,0.7),new=TRUE)
## boxplot(Mortality,lwd=1)
#
#

#
dev.off()
#
hull<-chull(SO2,Mortality)
plot(SO2,Mortality,pch=1)
polygon(SO2[hull],Mortality[hull],density=15,angle=30)
cor(SO2,Mortality)
cor(SO2[-hull],Mortality[-hull])
#
dev.off()
####################################
#
chiplot(SO2,Mortality,vlabs=c("SO2","Mortality"))
#

#
#
dev.off()
#####################################
#
bivbox(cbind(SO2,Mortality),xlab="SO2",ylab="Mortality")
#
#
dev.copy2eps(file="figure2.6.eps")
#
#
bivbox(cbind(SO2,Mortality), xlab="SO2", ylab="Mortality", method="O")
#

#
###########################################################
h2d<-hist2d(SO2,Mortality)
persp(h2d,xlab="SO2",ylab="Mortality",zlab="Frequency")
#
#
den1<-bivden(SO2,Mortality)
# ���̃v���b�g�́C�e�L�X�g�̂��̂́CS-Plus �ō쐬����Ă���
persp(den1$seqx,den1$seqy,den1$den,xlab="SO2",ylab="Mortality", zlab="Density",lwd=2)
#######
#
plot(SO2,Mortality)
contour(den1$seqx,den1$seqy,den1$den,lwd=2,nlevels=20,add=TRUE)

#
#########################3
plot(SO2,Mortality,pch=1, lwd=1, ylim=c(700,1200), xlim=c(-5,300))
symbols(SO2,Mortality, circles=Rainfall, inches=0.4,add=TRUE, lwd=1)

#
#########################################################333
pairs(airpoll)

#
pairs(airpoll,panel=function(x,y) {abline(lsfit(x,y)$coef,lwd=2)
                                  lines(lowess(x,y),lty=2,lwd=2)
                                  points(x,y)})
#

#
coplot(Mortality~SO2|Popden)

#
coplot(Mortality~SO2|Popden, panel=function(x,y,col,pch)
 panel.smooth(x,y,span=1))

#
########################

bivden<-function(x, y, ngridx = 30, ngridy = 30, constant.x = 1, constant.y = 1) {
	#x and y are vectors containing the bivariate data
	#ngridx and ngridy are the number of points in the grid
	#
	mx <- mean(x)
	sdx <- sqrt(var(x))
	my <- mean(y)
	sdy <- sqrt(var(y))
	#scale x and y before estimation
	x <- scale(x)
	y <- scale(y)
	#
	den <- matrix(0, ngridx, ngridy)
	#
	#find possible value for bandwidth
	#
	n <- length(x)
	#
	hx <- constant.x * n^(-0.2)
	hy <- constant.y * n^(-0.2)
	h <- hx * hy
	hsqrt <- sqrt(h)
	#
	seqx <- seq(range(x)[1], range(x)[2], length = ngridx)
	seqy <- seq(ra<nge(y)[1], range(y)[2], length = ngridy)
	#
	for(i in 1:n) {
		X <- x[i]
		Y <- y[i]
		xx <- (seqx - X)/hsqrt
		yy <- (seqy - Y)/hsqrt
		den <- den + outer(xx, yy, function(x, y)
			exp(-0.5 * (x^2 + y^2)))
			}
		den <- den/(n * 2 * pi * h)
		seqx <- sdx * seqx + mx
	seqy <- sdy * seqy + my
	result <- list(seqx = seqx, seqy = seqy, den = den)
	result
}
###########################################################
chiplot<-function(x,y,vlabs=c("X","Y"),matrix="NO") {
  n<-length(x)
  ind<-numeric(length=n)
  for(i in 1:n) {
    for(j in (1:n)[-i])	if(x[i]>x[j]&y[i]>y[j]) ind[i]<-ind[i]+1
  }
  ind<-ind/(n-1)
                                        #
  ind1<-numeric(length=n)
  for(i in 1:n) {
    for(j in (1:n)[-i])	if(x[i]>x[j]) ind1[i]<-ind1[i]+1
  }
  ind1<-ind1/(n-1)
                                        #
  ind2<-numeric(length=n)
  for(i in 1:n) {
    for(j in (1:n)[-i])	if(y[i]>y[j]) ind2[i]<-ind2[i]+1
  }
  ind2<-ind2/(n-1)
                                        #
  s<-sign((ind1-0.5)*(ind2-0.5))
                                        #
  chi<-(ind-ind1*ind2)/sqrt(ind1*(1-ind1)*ind2*(1-ind2))
                                        #
  lambda<-4*s*pmax((ind1-0.5)^2,(ind2-0.5)^2)
  thresh<-4*(1/(n-1)-0.5)^2
                                        # 
#
  if(matrix=="NO") {
    par(mfrow=c(1,2))
    plot(x,y,xlab=vlabs[1],ylab=vlabs[2])
    plot(lambda[abs(lambda)<thresh],chi[abs(lambda)<thresh],ylim=c(-1,1),xlab="lambda",
         ylab="Chi")
    abline(h=1.78/sqrt(n))
    abline(h=-1.78/sqrt(n))}
  if(matrix=="YES") {
    plot(lambda[abs(lambda)<thresh],chi[abs(lambda)<thresh],ylim=c(-1,1))
    abline(h=1.78/sqrt(n))
    abline(h=-1.78/sqrt(n))}
    #
}
#
###################################################################
bivbox<-function(a, d = 7, mtitle = "Bivariate Boxplot",
 method = "robust",xlab="X",ylab="Y")
{
#
#a is data matrix
#d is constant(usually 7)
#
	p <- length(a[1,  ])
	if(method == "robust") {
		param <- biweight(a[, 1:2])
		m1 <- param[1]
		m2 <- param[2]
		s1 <- param[3]
		s2 <- param[4]
		r <- param[5]
	}
	else {
		m1 <- mean(a[, 1])
		m2 <- mean(a[, 2])
		s1 <- sqrt(var(a[, 1]))
		s2 <- sqrt(var(a[, 2]))
		r <- cor(a[, 1:2])[1, 2]
	}
	x <- (a[, 1] - m1)/s1
	y <- (a[, 2] - m2)/s2
	e <- sqrt((x * x + y * y - 2 * r * x * y)/(1 - r * r))
	e2 <- e * e
	em <- median(e)
	emax <- max(e[e2 < d * em * em])
	r1 <- em * sqrt((1 + r)/2)
	r2 <- em * sqrt((1 - r)/2)
	theta <- ((2 * pi)/360) * seq(0, 360, 3)
	xp <- m1 + (r1 * cos(theta) + r2 * sin(theta)) * s1
	yp <- m2 + (r1 * cos(theta) - r2 * sin(theta)) * s2
	r1 <- emax * sqrt((1 + r)/2)
	r2 <- emax * sqrt((1 - r)/2)
	theta <- ((2 * pi)/360) * seq(0, 360, 3)
	xpp <- m1 + (r1 * cos(theta) + r2 * sin(theta)) * s1
	ypp <- m2 + (r1 * cos(theta) - r2 * sin(theta)) * s2
	maxxl <- max(xpp)
	minxl <- min(xpp)
	maxyl <- max(ypp)
	minyl <- min(ypp)
	b1 <- (r * s2)/s1
	a1 <- m2 - b1 * m1
	y1 <- a1 + b1 * minxl
	y2 <- a1 + b1 * maxxl
	b2 <- (r * s1)/s2
	a2 <- m1 - b2 * m2
	x1 <- a2 + b2 * minyl
	x2 <- a2 + b2 * maxyl
	maxx <- max(c(a[, 1], xp, xpp, x1, x2))
	minx <- min(c(a[, 1], xp, xpp, x1, x2))
	maxy <- max(c(a[, 2], yp, ypp, y1, y2))
	miny <- min(c(a[, 2], yp, ypp, y1, y2))
	plot(a[, 1], a[, 2], xlim = c(minx, maxx), ylim = c(miny, maxy), xlab =xlab, ylab =ylab,
	 lwd = 2, pch = 1)
	lines(xp, yp, lwd = 2)
	lines(xpp, ypp, lty = 2, lwd = 2)
	segments(minxl, y1, maxxl, y2, lty = 3, lwd = 2)
	segments(x1, minyl, x2, maxyl, lty = 4, lwd = 2)
}
#
################################################################
biweight<-function(a,const1=9,const2=36,err=0.0001) {
#
#a is data matrix with two cols.
#const1=common tuning constant
#const2=bivariate tuning constant
#err=convergence criterion.
#
              x<-a[,1]
              y<-a[,2]
              n<-length(x)
              mx<-median(x)
              my<-median(y)
              madx<-median(abs(x-mx))
              mady<-median(abs(y-my))
              if(madx != 0) { ux<-(x-mx)/(const1*madx)
                              ux1<-ux[abs(ux)<1]
                              tx<-mx+(sum((x[abs(ux)<1]-mx)*(1-ux1*ux1)^2)/
                                     sum((1-ux1^2)^2))
                              sx<- sqrt(n)*sqrt(sum((x[abs(ux)<1]-mx)^2*
                                   (1-ux1*ux1)^4))/abs(sum((1-ux1*ux1)*
                                    (1-5*ux1*ux1)))
                             }
                  else { tx<-mx
                         sx<-sum(abs(x-mx))/n
                       }
              if(mady != 0) { uy<-(y-my)/(const1*mady)
                              uy1<-uy[abs(uy)<1]
                              ty<-my+(sum((y[abs(uy)<1]-my)*(1-uy1*uy1)^2)/
                                     sum((1-uy1^2)^2))
                              sy<- sqrt(n)*sqrt(sum((y[abs(uy)<1]-my)^2*
                                   (1-uy1*uy1)^4))/abs(sum((1-uy1*uy1)*
                                    (1-5*uy1*uy1)))
                             }
                  else { ty<-my
                         sy<-sum(abs(y-my))/n
                       }
               z1<-(y-ty)/sy+(x-tx)/sx
               z2<-(y-ty)/sy-(x-tx)/sx
              mz1<-median(z1)
              mz2<-median(z2)
              madz1<-median(abs(z1-mz1))
              madz2<-median(abs(z2-mz2))
              if(madz1 != 0) { uz1<-(z1-mz1)/(const1*madz1)
                              uz11<-uz1[abs(uz1)<1]
                           tz1<-mz1+(sum((z1[abs(uz1)<1]-mz1)*(1-uz11*uz11)^2)/
                                     sum((1-uz11^2)^2))
                              sz1<- sqrt(n)*sqrt(sum((z1[abs(uz1)<1]-mz1)^2*
                                   (1-uz11*uz11)^4))/abs(sum((1-uz11*uz11)*
                                    (1-5*uz11*uz11)))
                             }
                  else { tz1<-mz1
                         sz1<-sum(abs(z1-mz1))/n
                       }
              if(mady != 0) { uz2<-(z2-mz2)/(const1*madz2)
                              uz21<-uz2[abs(uz2)<1]
                          tz2<-mz2+(sum((z2[abs(uz2)<1]-mz2)*(1-uz21*uz21)^2)/
                                     sum((1-uz21^2)^2))
                              sz2<- sqrt(n)*sqrt(sum((z2[abs(uz2)<1]-mz2)^2*
                                   (1-uz21*uz21)^4))/abs(sum((1-uz21*uz21)*
                                    (1-5*uz21*uz21)))
                             }
                  else { tz2<-mz2
                         sz2<-sum(abs(z2-mz2))/n
                       }
              esq<-((z1-tz1)/sz1)^2+((z2-tz2)/sz2)^2
              w<-numeric(length=n)
              c2<-const2
              for(i in 1:10) {
              w[esq<const2]<-(1-esq[esq<const2]/const2)^2
              w[esq>=const2]<-0
              l<-length(w[w==0])
              if(l<0.5*n) break
                  else const2<-2*const2
                            }
               tx<-sum(w*x)/sum(w)
               sx<-sqrt(sum(w*(x-tx)^2)/sum(w))
               ty<-sum(w*y)/sum(w)
               sy<-sqrt(sum(w*(y-ty)^2)/sum(w))
               r<-sum(w*(x-tx)*(y-ty))/(sx*sy*sum(w))
               const2<-c2
               wold<-w
            for(i in 1:100) {
                     z1<-((y-ty)/sy+(x-tx)/sx)/sqrt(2*(1+r))
                     z2<-((y-ty)/sy-(x-tx)/sx)/sqrt(2*(1+r))
                     esq<-z1*z1+z2*z2
                     for(j in 1:10) {
                                    w[esq<const2]<-(1-esq[esq<const2]/const2)^2
                                    w[esq>=const2]<-0
                                    l<-length(w[w==0])
                                    if(l<0.5*n) break
                                         else const2<-2*const2
                                     }
               tx<-sum(w*x)/sum(w)
               sx<-sqrt(sum(w*(x-tx)^2)/sum(w))
               ty<-sum(w*y)/sum(w)
               sy<-sqrt(sum(w*(y-ty)^2)/sum(w))
               r<-sum(w*(x-tx)*(y-ty))/(sx*sy*sum(w))
               term<-sum((w-wold)^2)/(sum(w)/n)^2
               if(term<-err) break
                    else {wold<-w
                          const2<-c2
                         }
                             }
            param<-c(tx,ty,sx,sy,r)
            param
}



##########################################################
#
#
#                         �� 3 ��
#
#                       �听������
#
###### chapter 3 ########################################

usair.dat <- source("Data/chap3usair.dat")$value

# p.51
# install.packages("car")
head(usair.dat)
row.names(usair.dat)
library(car)
scatterplot.matrix(usair.dat[,-1],diagonal= "histo" )
plot(usair.dat)
#

#
attach(usair.dat)
# �听������
cor(usair.dat[,-1])
usair.pc <- princomp(usair.dat[,-1], cor=TRUE)
summary(usair.pc)
summary(usair.pc, loadings = TRUE)
#
library(xtable)
xtable(cor(usair.dat[,-1]))

library(Hmisc)
latex(round(cor(usair.dat[,-1]), 3) , file='', longtable = T, label = "table3.2", caption = "�\ 3.2")
latex(round(cor(usair.dat[,-1]), 3) , file='', booktabs=T, dcolumn=T)
# latex(cor(usair.dat[,-1]), booktabs=T,dcolumn=T)       
#xtable(summary(usair.pc) )
# xtable(usair.pc)
#
# latex(summary(usair.pc,loadings=TRUE),file='', longtable = T, label = "table3.2", caption = "�\ 3.2")

###################  p.54
par(pty="s")
plot(usair.pc$scores[,1],usair.pc$scores[,2],ylim=range(usair.pc$scores[,1]),xlab="PC1",ylab="PC2",type="n",lwd=2)
text(usair.pc$scores[,1],usair.pc$scores[,2],labels=abbreviate(row.names(usair.dat)),cex=0.7,lwd=2)
#
##

#
#
par(pty="s")
plot(usair.pc$scores[,1],usair.pc$scores[,3],
ylim=range(usair.pc$scores[,1]),
xlab="PC1",ylab="PC3",type="n",lwd=2)
text(usair.pc$scores[,1],usair.pc$scores[,3],
labels=abbreviate(row.names(usair.dat)),cex=0.7,lwd=2)


#
#
par(pty="s")
plot(usair.pc$scores[,2],usair.pc$scores[,3],
ylim=range(usair.pc$scores[,2]),
xlab="PC2",ylab="PC3",type="n",lwd=2)
text(usair.pc$scores[,2],usair.pc$scores[,3],
labels=abbreviate(row.names(usair.dat)),cex=0.7,lwd=2)



############ 
usair1.dat <- data.frame(cities = row.names(usair.dat), usair.dat, usair.pc$scores[,1:3])
# persp(usair1.dat$Comp.1, usair1.dat$Comp.2, usair1.dat$Comp.3)
attach(usair1.dat)

#
############## p.55
usair.pc$scores[,1:3]
latex (round(usair.pc$scores[,1:3], 3), file = "", longtable = T, caption = "�e�s�s�̎听�����_", label = "table3.3")
#
attach(usair.dat)

par(mfrow=c(1,3))
plot(usair.pc$scores[,1],SO2,xlab="PC1")
plot(usair.pc$scores[,2],SO2,xlab="PC2")
plot(usair.pc$scores[,3],SO2,xlab="PC3")
#


######### p.56
summary(lm(SO2 ~ usair.pc$scores[,1] + usair.pc$scores[,2] + usair.pc$scores[,3]))
#
latex(summary(lm(SO2 ~ usair.pc$scores[,1] + usair.pc$scores[,2] + usair.pc$scores[,3])), caption = "�d��A���͂̌���", label = "table3.4", file = "")
#
plot(usair.pc$scores[,1],SO2,xlab="PC1",ylab="SO2")
#
#load(lqs)
library(lqs)
#
library(MASS)
#
usair.mve<-cov.mve(usair.dat[,-1],cor=TRUE)
#
usair.mve$cor
usair.pc1<-princomp(usair.dat[,-1],covlist=usair.mve,cor=TRUE)
summary(usair.pc1,loadings=T)
#
#
#Chapter 8
usair.fit<-lm(SO2~Neg.Temp+Manuf+Pop+Wind+Precip+Days)
summary(usair.fit)

####################################################################
life <- source("Data/chap4lifeexp.dat")$value
#
#
attach(life)
#
#
life.fa1<-factanal(life,factors=1,method="mle")
life.fa1
#
life.fa2<-factanal(life,factors=2,method="mle")
life.fa2
#
life.fa3<-factanal(life,factors=3,method="mle")
life.fa3
#
summary(life.fa3)
1 - life.fa3$uniqueness

############ �Ό��������߂�
#install.packages("GPArotation")
library(GPArotation)
fa.unrotated  <- factanal(life, factors = 3, normalize=TRUE, method="mle", rotation="none")
GPForth(loadings(fa.unrotated), method="quartimax", normalize=TRUE)$loadings
#############

scores <- factanal(life,factors=3,method="mle",scores="regression")$scores
#
# library(rgl)
# cloud(scores)
library(scatterplot3d)
scatterplot3d(scores)
# p.79
lifex <- data.frame(life, scores)
#
attach(lifex)

library(lattice)
head(scores)
## panel.cloud(x = scores$Factor1,y = scores$Factor2, sub = rownames(scores), z = scores$Factor3,perspective = TRUE)
panel.3dscatter(x = scores$Factor1,y = scores$Factor2, z = scores$Factor3,perspective = TRUE)


########## p. 82
druguse.cor<-source("Data/chap4druguse.dat")$value
#
#
druguse.fa<-lapply(1:6,function(nf) factanal(covmat=druguse.cor,factors=nf,method="mle",n.obs=1634))
#
druguse.fa[[6]]
#
pred <- druguse.fa[[6]]$loadings %*% t(druguse.fa[[6]]$loadings)+
   diag(druguse.fa[[6]]$uniquenesses)
#
#
round(druguse.cor - pred, digits = 3)
#
pred<-druguse.fa[[3]]$loadings%*%t(druguse.fa[[3]]$loadings)+diag(druguse.fa[[3]]$uniquenesses)

round(druguse.cor-pred,digits=3)
#
pred<-druguse.fa[[4]]$loadings%*%t(druguse.fa[[4]]$loadings)+diag(druguse.fa[[4]]$uniquenesses)
round(druguse.cor-pred,digits=3)






#######################################################################
#
#
#                               �� 4 ��
#
#                            �T���I���q����            
#
#
########################################################################

life<-source("Data/chap4lifeexp.dat")$value#

row.names(life)[30] <- "Colombia"
row.names(life)[7] <- "South Africa(B)"
row.names(life)
##########
options(X11fonts = c("-alias-mincho-%s-%s-*-*-%d-*-*-*-*-*-*-*","-adobe-symbol-*-*-*-*-%d-*-*-*-*-*-*-*"))
 ps.options(family= "Japan1Ryumin") # Windows �ł͂����������s
##
#
par(mfrow=c(1,3))
plclust(hclust(dist(life),method="single"),labels=row.names(life),ylab="Distance")
title("(a) Single linkage")
plclust(hclust(dist(life),method="complete"),labels=row.names(life),ylab="Distance")
title("(b) Complete linkage")
plclust(hclust(dist(life),method="average"),labels=row.names(life),ylab="Distance")
title("(c) Average linkage")

par(mfrow=c(1,3))
plclust(hclust(dist(life),method="single"),labels=row.names(life),ylab="����")
title("(a) �ŒZ�����@")
plclust(hclust(dist(life),method="complete"),labels=row.names(life),ylab="����")
title("(b) �Œ������@")
plclust(hclust(dist(life),method="average"),labels=row.names(life),ylab="����")
title("(c) �Q���ϖ@")


four<-cutree(hclust(dist(life),method="complete"),h=21);four
#
#
country.clus<-lapply(1:5,function(nc) row.names(life)[four==nc])
country.mean<-lapply(1:5,function(nc) apply(life[four==nc,],2,mean))
country.mean
country.clus
#
dev.off()
#
pairs(life,panel=function(x,y) text(x,y,four))
#










########################################################################
#
#
#
#                          �� 5 ��
#
#                  �������ړx�\���@�ƑΉ�����
#
#
########################################################################


# p.97
x <- matrix(c(3,4,4,6,1,
       5,1,1,7,3,
       6,2,0,2,6,
       1,1,1,0,3,
       4,7,3,6,2,
       2,2,5,1,0,
       0,4,1,1,1,
       0,6,4,3,5,
       7,6,5,1,4,
       2,1,4,3,1), byrow = T, ncol = 5)

cmdscale(dist(x), k = 5)
round(cmdscale(dist(x), k = 5), digit = 3)
dist(x) - dist(cmdscale(dist(x), k = 5))


######### p.98
airline.dist <- source("Data/chap5airdist.dat")$value

#
 airline.mds<-cmdscale(as.matrix(airline.dist), k = 9, eig = T)
#airline.mds<-cmdscale(as.matrix(airline.dist), k = 9, eig = T)
airline.mds$eig
#
eigen(scale(as.matrix(airline.dist)))
eigen(as.matrix(airline.dist))

# aoki
princo(as.matrix(airline.dist))


#######
#p^1
sum(abs(airline.mds$eig[1]))/sum(abs(airline.mds$eig))
sum(airline.mds$eig[1]^2)/sum(airline.mds$eig^2)

#p^2
sum(abs(airline.mds$eig[1:2]))/sum(abs(airline.mds$eig))
sum(airline.mds$eig[1:2]^2)/sum(airline.mds$eig^2)
#
#x11()
par(pty="s")
plot(-1 * airline.mds$points[,1], airline.mds$points[,2], type="n", xlab="Coordinate 1", ylab="Coordinate 2", xlim=c(-2000,1500), ylim=c(-2000,1500))
text(-1 * airline.mds$points[,1], airline.mds$points[,2], labels=row.names(airline.dist))

#dev.off()
#
x11()
par(pty="s")
plot(airline.mds$points[,1], airline.mds$points[,2], type = "n", xlab = "Coordinate 1", ylab="Coordinate 2", xlim = c(-2000,1500), ylim = c(-2000,1500))
text(airline.mds$points[,1], airline.mds$points[,2], labels = row.names(airline.dist))

sex<-matrix(c(21,21,14,13,8,8,9,6,8,2,2,3,4,10,10),ncol=5,byrow=TRUE)
#
ncol<-5
nrow<-3
n<-sum(sex)
rtot<-apply(sex,1,sum)
ctot<-apply(sex,2,sum)
#
xrtot<-cbind(rtot,rtot,rtot,rtot,rtot)
xctot<-rbind(ctot,ctot,ctot)
#
xrtot<-sex/xrtot
xctot<-sex/xctot
#
rdot<-rtot/n
cdot<-ctot/n
dcols<-matrix(0,ncol,ncol)
for(i in 1:ncol){
	 for(j in 1:ncol){d<-0
	      for(k in 1:nrow) d<-d+(xctot[k,i]-xctot[k,j])^2/rdot[k]
	      dcols[i,j]<-sqrt(d)}}
	#
drows<-matrix(0,nrow,nrow)
for(i in 1:nrow){
	 for(j in 1:nrow){d<-0
	      for(k in 1:ncol) d<-d+(xrtot[i,k]-xrtot[j,k])^2/cdot[k]
	      drows[i,j]<-sqrt(d)}}

#
#
r1<-cmdscale(dcols,eig=TRUE)
#r1<-cmdscale(drows,eig=TRUE)
r1$points
r1$eig
c1<-cmdscale(drows,eig=TRUE)
#c1<-cmdscale(dcols,eig=TRUE)
c1$points
c1$eig
xrtot
par(pty="s")
plot(r1$points,xlim=range(r1$points[,1],c1$points[,1]),ylim=range(r1$points[,1],c1$points[,1]),type="n",
xlab="Coordinate 1",ylab="Coordinate 2",lwd=2)
text(r1$points,labels=c("AG1","AG2","AG3","AG4","AG5"),lwd=2)
text(c1$points,labels=c("nobf","bfns","bfs"),lwd=4)
#
abline(h=0,lty=2)
abline(v=0,lty=2)
#
#
################ 
skulls<-source("Data/chap5skulls.dat")$value
#
#
#
#Mahalanobis distances 
#
#
labs<-rep(1:5,rep(30,5))
#
centres<-matrix(0,5,4)
S<-matrix(0,4,4)
#
for(i in 1:5) {
	           centres[i,]<-apply(skulls[labs==i,-1],2,mean)
	          S<-S+29*var(skulls[,-1])
}
#
S<-S/145
#
mahal<-matrix(0,5,5)
#
for(i in 1:5) {
	mahal[i,]<-mahalanobis(centres,centres[i,],S)
}
#
par(pty="s")
coords<-cmdscale(mahal)
xlim<-c(-1.5,1.5)
plot(coords,xlab="C1",ylab="C2",type="n",xlim=xlim,ylim=xlim,lwd=2)
text(coords,labels=c("c4000BC","c3300BC","c1850BC","c200BC","cAD150"),lwd=3)
#




## #######################################################
## # p. 106
sex < -matrix(c(21,21,14,13,8,8,9,6,8,2,2,3,4,10,10),ncol=5,byrow=TRUE)
#
ncol.sex <-5
nrow.sex <-3
n <-sum(sex)
rtot<-apply(sex,1,sum)
ctot<-apply(sex,2,sum)
#
xrtot<-cbind(rtot,rtot,rtot,rtot,rtot)
xctot<-rbind(ctot,ctot,ctot)
#
xrtot<-sex/xrtot
xctot<-sex/xctot
#
rdot<-rtot/n
cdot<-ctot/n

##################################
dcols<-matrix(0,ncol.sex,ncol.sex)
for(i in 1:ncol.sex){
	 for(j in 1:ncol.sex){d<-0
	      for(k in 1:nrow.sex) d<-d+(xctot[k,i]-xctot[k,j])^2/rdot[k]
	      dcols[i,j]<-sqrt(d)}}
	#
#################################
drows<-matrix(0,nrow.sex,nrow.sex)
for(i in 1:nrow.sex){
	 for(j in 1:nrow.sex){d<-0
	      for(k in 1:ncol.sex) d<-d+(xrtot[i,k]-xrtot[j,k])^2/cdot[k]
	      drows[i,j]<-sqrt(d)}}

#
#r1
# r1<-cmdscale(dcols,eig=TRUE)
r1<-cmdscale(drows,eig=TRUE)
r1$points
r1$eig
# c1<-cmdscale(drows,eig=TRUE)
c1<-cmdscale(dcols,eig=TRUE)
c1$points
c1$eig
xrtot
#
#
par(pty="s")
plot(r1$points,xlim=range(r1$points[,1],c1$points[,1]),ylim=range(r1$points[,1],c1$points[,1]),type="n",xlab="Coordinate 1",ylab="Coordinate 2",lwd=2)

text(r1$points,labels=c("AG1","AG2","AG3","AG4","AG5"),lwd=2)

text(c1$points,labels=c("nobf","bfns","bfs"),lwd=4)

#
abline(h=0,lty=2)
abline(v=0,lty=2)
#
######## #plot(-1 * r1$points,xlim=range(-1 * r1$points[,1],c1$points[,1]),ylim=range(-1 * r1$points[,1],c1$points[,1]),type="n",xlab="Coordinate 1",ylab="Coordinate 2",lwd=2)
#
########3 #text(-1 * r1$points,labels=c("AG1","AG2","AG3","AG4","AG5"),lwd=2)
########## #text(-1 * c1$points,labels=c("nobf","bfns","bfs"),lwd=4)
############3 #text(c1$points,labels=c("bfs", "bfns", "nobf"),lwd=4)


#################
skulls<-source("Data/chap5skulls.dat")$value
#
#
#
#Mahalanobis distances 
#
#
labs<-rep(1:5,rep(30,5))
#
centres<-matrix(0,5,4)
S<-matrix(0,4,4)
#
for(i in 1:5) {
	           centres[i,]<-apply(skulls[labs==i,-1],2,mean)
	          S<-S+29*var(skulls[,-1])
}
#
S<-S/145
#
mahal<-matrix(0,5,5)
#
for(i in 1:5) {
	mahal[i,]<-mahalanobis(centres,centres[i,],S)
}
#
par(pty="s")
coords<-cmdscale(mahal)
xlim<-c(-1.5,1.5)
plot(coords,xlab="C1",ylab="C2",type="n",xlim=xlim,ylim=xlim,lwd=2)
text(coords,labels=c("c4000BC","c3300BC","c1850BC","c200BC","cAD150"),lwd=3)
#
#
####################################################
# newbabies <- matrix(c(50+9+315+40, 41+4+147+11, 24+6+4012+459, 14+1+1594+124), ncol = 2)

# newbabies <- matrix(c(50, 9, 41, 4,   315147, 11,24, 6, 4012, 459,14,1,1594, 124), ), 

# newbabies <- array(c(matrix(c(50, 9, 315, 40), ncol = 2), matrix(c(41, 4, 147, 11), ncol = 2), matrix(c(24, 6, 4012, 459), ncol = 2), matrix(c(14,1,1594, 124), ncol = 2)), dim = c(4, 4, 1))

# chisq.test(newbabies[,1])

# newbabies <- list(matrix(c(50, 9, 315, 40)), matrix(c(41, 4, 147, 11)), matrix(c(24, 6, 4012, 459)), matrix(c(14,1,1594, 124)))
chisq.test(newbabies)

newbabies <- matrix(c(50, 9, 41, 4,  315, 40,147, 11,  24, 6, 14, 1, 4012, 459, 1594, 124), ncol = 4)


#chisq.test(newbabies)

# p. 110 - 111 �̏o��
ncol.babies <- 4
nrow.babies <- 4
n.babies <- sum(newbabies)
rtot.babies <- apply(newbabies,1,sum)
ctot.babies <- apply(newbabies,2,sum)
#
xrtot.babies <-cbind(rtot.babies, rtot.babies, rtot.babies, rtot.babies)
xctot.babies <-rbind(ctot.babies, ctot.babies, ctot.babies, ctot.babies)
#
xrtot.babies <- newbabies/xrtot.babies
xctot.babies <- newbabies/xctot.babies
#
rdot.babies <- rtot.babies/n.babies
cdot.babies <- ctot.babies/n.babies

##################################
dcols.babies <-matrix(0, ncol.babies, ncol.babies)
for(i in 1:ncol.babies){
	 for(j in 1:ncol.babies){d<-0
	      for(k in 1:nrow.babies) d<-d+(xctot.babies[k,i]-xctot.babies[k,j])^2/rdot.babies[k]
	      dcols.babies[i,j]<-sqrt(d)}}
	#
#################################
drows.babies <-matrix(0, nrow.babies,nrow.babies)
for(i in 1:nrow.babies){
	 for(j in 1:nrow.babies){d<-0
	      for(k in 1:ncol.babies) d<-d+(xrtot.babies[i,k]-xrtot.babies[j,k])^2/cdot.babies[k]
	      drows.babies[i,j]<-sqrt(d)}}

#####################################
#r1
r1.babies <- cmdscale(dcols.babies, eig=TRUE)
#r1.babies<-cmdscale(drows.babies, eig=TRUE)
r1.babies$points
r1.babies$eig

c1.babies <- cmdscale(drows.babies, eig=TRUE)
#c1.babies<-cmdscale(dcols.babies, eig=TRUE)
c1.babies$points
c1.babies$eig
#
#
par(pty="s")
plot(r1.babies$points, xlim = range(r1.babies$points[,1], c1.babies$points[,1]), ylim = range(r1.babies$points[,1], c1.babies$points[,1]),   type="n",  xlab = "Coordinate 1", ylab = "Coordinate 2", lwd = 2)

#text(r1.babies$points, labels = c("YN","YS","ONS","OS"), lwd=2)
#text(c1.babies$points, labels = c("pd","pa","ftd","fta"), lwd=4)
##
text(c1.babies$points, labels = c("YN","YS","ONS","OS"), lwd=2)
text(r1.babies$points, labels = c("pd","pa","ftd","fta"), lwd=4)
#
abline(h=0,lty=2)
abline(v=0,lty=2)

dev.off()

## nb1 <- (newbabies[1,1] / sum(newbabies[,1]))
## nb2 <- (newbabies[1,2] / sum(newbabies[,2]))
## nb.sum1 <- sum (newbabies[1,]) / sum(newbabies)
## (nb1 - nb2)^2 / nb.sum1

##################
hodgkin <- matrix(c(74,68,154,18,   18,16,54,10,  12,12,58,44), ncol  = 3) 
#
chisq.test(hodgkin )
#
ncol.hodgkin <- 3
nrow.hodgkin <- 4
n.hodgkin <- sum(hodgkin)
rtot.hodgkin <- apply(hodgkin,1,sum)
ctot.hodgkin <- apply(hodgkin,2,sum)
#
xrtot.hodgkin <-cbind(rtot.hodgkin, rtot.hodgkin, rtot.hodgkin)
xctot.hodgkin <-rbind(ctot.hodgkin, ctot.hodgkin, ctot.hodgkin, ctot.hodgkin)
#
xrtot.hodgkin <- hodgkin/xrtot.hodgkin
xctot.hodgkin <- hodgkin/xctot.hodgkin
#
rdot.hodgkin <- rtot.hodgkin/n.hodgkin
cdot.hodgkin <- ctot.hodgkin/n.hodgkin

##################################
dcols.hodgkin <-matrix(0, ncol.hodgkin, ncol.hodgkin)
for(i in 1:ncol.hodgkin){
	 for(j in 1:ncol.hodgkin){d<-0
	      for(k in 1:nrow.hodgkin) d<-d+(xctot.hodgkin[k,i]-xctot.hodgkin[k,j])^2/rdot.hodgkin[k]
	      dcols.hodgkin[i,j]<-sqrt(d)}}
	#
#################################
drows.hodgkin <-matrix(0, nrow.hodgkin, nrow.hodgkin)
for(i in 1:nrow.hodgkin){
	 for(j in 1:nrow.hodgkin){d<-0
	      for(k in 1:ncol.hodgkin) d<-d+(xrtot.hodgkin[i,k]-xrtot.hodgkin[j,k])^2/cdot.hodgkin[k]
	      drows.hodgkin[i,j]<-sqrt(d)}}

#####################################
#r1
r1.hodgkin <-cmdscale(dcols.hodgkin, eig=TRUE)
#r1.hodgkin <-cmdscale(drows.hodgkin, eig=TRUE)

r1.hodgkin$points
r1.hodgkin$eig

c1.hodgkin <-cmdscale(drows.hodgkin, eig=TRUE)
#c1.hodgkin<-cmdscale(dcols.hodgkin, eig=TRUE)

c1.hodgkin$points
c1.hodgkin$eig
#
#
par(pty="s")
plot(r1.hodgkin$points, xlim=range(r1.hodgkin$points[,1], c1.hodgkin$points[,1]), ylim=range(r1.hodgkin$points[,1], c1.hodgkin$points[,1]),  type="n",  xlab="Coordinate 1",  ylab="Coordinate 2",  lwd=2)

#text(r1.hodgkin$points, labels = c("LP", "NS", "MC", "LD"), lwd=2)
#text(c1.hodgkin$points, labels = c("Pos","Par","None"), lwd=4)
#
text(c1.hodgkin$points, labels = c("LP", "NS", "MC", "LD"), lwd=2)
text(r1.hodgkin$points, labels = c("Pos","Par","None"), lwd=4)
abline(h=0,lty=2)
abline(v=0,lty=2)


########################################################################
#
#
#
#                      �� 6 ��
#
#                  �N���X�^�[����
#
#
#########################################################################
life <- source("Data/chap4lifeexp.dat")$value

plot(life)

# p.118
country <- row.names(life)
par(mfrow = c(1,3))
plclust(hclust(dist(life), method = "single"), labels = country, ylab = "Distance")
title("(a) Sigle linkage")

plclust(hclust(dist(life), method = "complete"), labels = country, ylab = "Distance")
title("(b) Complete linkage")
plclust(hclust(dist(life), method = "average"), labels = country, ylab = "Distance")
title("(C) Average linkage")

four <- cutree(hclust(dist(life),method = "complete"),h = 21)
country.clus <- lapply(1:5, function(nc) country[four == nc])

country.mean <- lapply(1:5, function(nc) apply(life[four == nc, ], 2, mean))

pairs(life, panel= function (x,y) text(x,y,four))

#########
#
pottery.data <- source("Data/chap6pottery.data")$value


rge<-apply(pottery.data, 2, max)-apply(pottery.data, 2, min);rge
pottery.dat<-sweep(pottery.data,2,rge,FUN="/"); pottery.dat
pottery.dat[39:40,]
#
n<-length(pottery.dat[,1])
wss1<-(n-1)*sum(apply(pottery.dat,2,var))
wss<-numeric(0)
for(i in 2:6) {
	   W<-sum(kmeans(pottery.dat,i)$withinss)
	   wss<-c(wss,W)
}
#
wss<-c(wss1,wss)
plot(1:6,wss,type="l",xlab="Number of groups",ylab="Within groups sum of squares",lwd=2)


plot(1:6,wss,type="l",xlab="�Q�̐�",ylab="�Q�������a",lwd=2)
#



plot(1:6,wss,type="l",xlab="�Q�̐�",ylab="�Q�������a",lwd=2)
dev.off()

#
#############################
pottery.kmean<-kmeans(pottery.dat,3)
pottery.kmean


lapply(1:3,function(nc) apply(pottery.data[pottery.kmean$cluster==nc,],2,mean))
#
#
kiln<-c(rep(1,21),rep(2,12),rep(3,2),rep(4,5),rep(5,5))
length(kiln)
#
# attach(pottery.dat)
table(kiln, pottery.kmean$cluster)
#table(pottery.dat$kiln, pottery.kmean$cluster)
#
planet.dat<-source("Data/chap6planet.dat")$value


#attach(planet.dat)
#detach(planet.dat)
planet.dat[55:56,]
planet.dat[56,1] <- 2.05
planet.dat[55:56,]

#
#install.packages("mclust02")
#install.packages("mclust")
#update.packages("mclust")

#library(mclust)
library(mclust02)
planet.clus<-Mclust(planet.dat)
#
plot(planet.clus, planet.dat, col = "black")
#plot(planet.clus, planet.dat, xlab = "�N���X�^�[�̐�")
# mclustBIC(planet.clus, planet.dat, xlab = "�N���X�^�[�̐�")


plot(planet.clus, planet.dat)

#enter 1
#
plot(planet.clus,planet.dat)
#enter 2
#
#enter 0
#
# planet.clus$mu
 planet.clus$mu
planet.clus$parameters$mean

table( planet.clus$classification)
length(planet.dat)

planet.clus<-Mclust(planet.dat, emModel = "EII")

plot(planet.clus, planet.dat)




###########################################################
#
#
#                                 �� 7 �� 
#
#                            ���Q���ϗʃf�[�^
#
#
###################################################### chapter7

Tibet <- source("Data/chap7tibetskull.dat")$value
#
attach(Tibet)
#
m1<-apply(Tibet[Type==1,-6],2,mean)
m2<-apply(Tibet[Type==2,-6],2,mean)
l1<-length(Type[Type==1])
l2<-length(Type[Type==2])
x1<-Tibet[Type==1,-6]
x2<-Tibet[Type==2,-6]
S123<-((l1-1)*var(x1)+(l2-1)*var(x2))/(l1+l2-2)
T2<-t(m1-m2)%*%solve(S123)%*%(m1-m2)
#
Fstat<-(l1+l2-5-1)*T2/(l1+l2-2)*5
pvalue<-1-pf(Fstat,5,26)
#
Fstat
pvalue
# ############## p. 144
m1<-apply(Tibet[Type==1,-6],2,mean)
m2<-apply(Tibet[Type==2,-6],2,mean)
l1<-length(Type[Type==1])
l2<-length(Type[Type==2])
x1<-Tibet[Type==1,-6]
x2<-Tibet[Type==2,-6]
S123<-((l1-1)*var(x1)+(l2-1)*var(x2))/(l1+l2-2)
a<-solve(S123)%*%(m1-m2)
z12<-(m1%*%a+m2%*%a)/2
#
z1<-m1%*%a
z2<-m2%*%a
z12
z1
z2
#
a
z12
#

#
library(MASS)
## S-PLUS # dis <- lda(Type ~ Length + Breadth + Height + Fheight + Fbreadth, data = Tibet, family = classical("homoscedastic"), prior="uniform")

#dis<-lda(Type~Length+Breadth+Height+Fheight+Fbreadth,data=Tibet,prior=c(0.5,0.5),family=Classical("homoscedastic"))
dis<-lda(Type~Length+Breadth+Height+Fheight+Fbreadth,data=Tibet,prior=c(0.5,0.5))

# dis<-lda(Type~Length+Breadth+Height+Fheight+Fbreadth,data=Tibet,prior=c(0.5,0.5), weight = 1) 
## dis<-lda(Type~Length+Breadth+Height+Fheight+Fbreadth,data=Tibet)
## dis<-lda(Type~Length+Breadth+Height+Fheight+Fbreadth,data=Tibet,prior=c(0.5,0.5), CVS = "T")
## dis<-lda(Type~Length+Breadth+Height+Fheight+Fbreadth,data=Tibet,prior=c(0.5,0.5), method = "moment")

## dis<-qda(Type~Length+Breadth+Height+Fheight+Fbreadth,data=Tibet,prior=c(0.5,0.5))
## dis

const <- coef(dis)
const[2] - const[1]

-mean(dis$means %*% dis$scaling)
#
#dis<-discrim(Type~Length+Breadth+Height+Fheight+Fbreadth,data=Tibet,prior=c(0.5,0.5))
newdata<-rbind(c(171,140.5,127.0,69.5,137.0),c(179.0,132.0,140.0,72.0,138.5))
dimnames(newdata) <-  list(NULL,c("Length", "Breadth", "Height","Fheight", "Fbreadth"))
## colnames(newdata)<- colnames(Tibet)[1:5]
#
newdata<-data.frame(newdata)
predict(dis,newdata=newdata)
#
#
group<-predict(dis,method="plug-in")$class
#
table(group,Type)

summary(dis)
#
#
#
#

skulls<-source("Data/chap5skulls.dat")$value
#
?summary.manova
attach(skulls)
skulls.manova<-manova(cbind(MB,BH,BL,NH)~EPOCH)
summary(skulls.manova,test="Pillai")
summary(skulls.manova,test="Wilks")
summary(skulls.manova,test="Hotelling")
summary(skulls.manova,test="Roy")
#
chisplot(residuals(skulls.manova))
#
#
#
dsfs1<-c(0.13,-0.04,-0.15,0.08)%*%t(skulls[,-1])
dsfs2<-c(0.04,0.21,-0.068,-0.08)%*%t(skulls[,-1])
m1<-c(mean(dsfs1[1:30]),mean(dsfs1[31:60]),mean(dsfs1[61:90]),mean(dsfs1[91:120]),mean(dsfs1[121:150]))
m2<-c(mean(dsfs2[1:30]),mean(dsfs2[31:60]),mean(dsfs2[61:90]),mean(dsfs2[91:120]),mean(dsfs2[121:150]))
plot(m1,m2,type="n",xlab="CV1",ylab="CV2",xlim=c(0.5,3))
text(m1,m2,labels=c("c4000BC","c3300BC","c1850BC","c200BC","cAD150"))




#########################################################
#
#
#                      �� 8 ��
#
#                  �d��A���͂Ɛ������֕���
#
#
################################################# chapter08

# p.159
usair.dat  <- source("Data/chap3usair.dat")$value

attach(usair.dat )

usair.fit <- lm(SO2 ~ Neg.Temp + Manuf + Pop + Wind + Precip + Days)
summary(usair.fit)

headsize <- source("Data/chap8headsize.dat")$value


#
## < %%%%%%%%%%%% �ȉ��Cpp.162 - 163 �����ǂ���.1 %%%%%%%%%%%%%>
headsize.std <- sweep(headsize, 2, sqrt(apply(headsize, 2, var)), FUN="/")
#standardize head measurements by
#dividing by the appropriate standard deviation
#
#
headsize1 <- headsize.std[, 1:2]
headsize2 <- headsize.std[, 3:4]
#
#find all the matrices necessary for calculating the
#canonical variates and canonical correlations
#
head(headsize1)
head(headsize1)
#
R11<-cor(headsize1)
R22<-cor(headsize2)
R12<-c(cor(headsize1[, 1], headsize2[,1]), cor(headsize1[, 1],
  headsize2[, 2]),
cor(headsize1[, 2], headsize2[, 1]), cor(headsize1[, 2],
  headsize2[, 2]))
#
R12 <- matrix(R12, ncol=2, byrow=T)  # byrow=T�͌����ǂ���D��΂ɕK�v
## #R12 <- matrix(R12, ncol=2) # ,byrow=T) # 
R21 <- t(R12)
#
#see display 8.2 for relevant equations
E1 <- solve(R11)%*%R12%*%solve(R22)%*%R21
E2 <- solve(R22)%*%R21%*%solve(R11)%*%R12
#
E1
E2
#
#
eigen(E1)
eigen(E2)
girth1 <- 0.73 * headsize.std[,1] + 0.69 * headsize.std[,2]
shape1 <- -0.70 * headsize.std[,1] + 0.71 * headsize.std[,2]
girth2 <- -0.68 * headsize.std[,3] - 0.73 * headsize.std[,4]
shape2 <- -0.71 * headsize.std[,3] + 0.71 * headsize.std[,4]
# ����������

girth1 <- 0.73 * headsize.std[,1] + 0.69 * headsize.std[,2]
shape1 <- 0.70 * headsize.std[,1] - 0.71 * headsize.std[,2]
girth2 <- 0.68 * headsize.std[,3] + 0.73 * headsize.std[,4]
shape2 <- 0.71 * headsize.std[,3] - 0.71 * headsize.std[,4]


cor(girth1,girth2)
cor(shape1,shape2)

#
sqrt(eigen(E1)$values)
sqrt(eigen(E2)$values)
#
par(mfrow=c(1,2))
plot(girth1,girth2)
plot(shape1,shape2)
#
#
## girth1<-0.69*headsize.std[,1]+0.72*headsize.std[,2]
## girth2<-0.74*headsize.std[,3]+0.67*headsize.std[,4]
## shape1<-0.71*headsize.std[,1]-0.71*headsize.std[,2]
## shape2<-0.70*headsize.std[,3]-0.71*headsize.std[,4]
## cor(girth1, girth2)
## cor(shape1, shape2)
## par(mfrow = c(1,2))
## plot(girth1, girth2)
## plot(shape1,shape2)

## </%%%%%%%%%%%%% �ȏ�C�Cpp.162 - 163 �����ǂ���.1 %%%%%%%%%> 
#
#
# var.head.12 <- sum( (headsize[,1:2] - mean(headsize[,1:2]))^2 ) / nrow( headsize)
# var(headsize[,3:4])
# solve(var(headsize[,1:2])) %*% cov(headsize[,1:2], headsize[,3:4]) %*% solve(var(headsize[,3:4])) %*%  cov(headsize[,1:2], headsize[,3:4])
# nrow(headsize[,1]) ; NULL

### S-PLUS for Windwos �̏o�͂ɂ͈ȉ��̃R�[�h������
## varp <- function (x) { sum( (x - mean(x))^2) /( length(x))}
# headsize.std <- sweep(headsize,2,sqrt(apply(headsize,2,varp)),FUN="/")
headsize.std <- sweep(headsize,2,sqrt(apply(headsize,2,var)),FUN="/")
headsize.std
#
#
headsize1<-headsize.std[,1:2]
headsize2<-headsize.std[,3:4]
r11<-cor(headsize1)
r11
r22<-cor(headsize2)
r22
r12<-c(cor(headsize1[,1],headsize2[,1]),cor(headsize1[,1],headsize2[,2]),  cor(headsize1[,2],headsize2[,1]),cor(headsize1[,2],headsize2[,2]))
r12
#
(r12<-matrix(r12, ncol=2,byrow=T))
(r12<-matrix(r12, ncol=2))#
r12
r21<-t(r12)
r21
#
E1<- solve(r11) %*% r12 %*% solve(r22) %*% r21
E2<- solve(r22) %*% r21 %*% solve(r11) %*% r12
E1
E2
#
eigen(E1)
eigen(E2)
#
sqrt(eigen(E1)$values)
t(eigen(E1)$vectors)
t(eigen(E2)$vectors)



#

## R1<-solve(r11)%*%r12%*%solve(r22)%*%r21
## R2<-solve(r22)%*%r21%*%solve(r11)%*%r12
## R1
## R2
## #
## eigen(R1)
## eigen(R2)
## #
## sqrt(eigen(R1)$values)

## #
## girth1<-0.69*headsize.std[,1]+0.72*headsize.std[,2]
## girth2<-0.74*headsize.std[,3]+0.67*headsize.std[,4]
## shape1<-0.71*headsize.std[,1]-0.71*headsize.std[,2]
## shape2<-0.70*headsize.std[,3]-0.71*headsize.std[,4]

## ### �Γc��L S-PLUS �̏o�͂Ɋ�Â� ��
## girth1 <-  0.72 * headsize.std[,1] + 0.68 * headsize.std[,2]
## girth2 <- -0.68 * headsize.std[,3] - 0.73 * headsize.std[,4]
## shape1 <- -0.71 * headsize.std[,1] + 0.71 * headsize.std[,2]
## shape2 <- -0.71 * headsize.std[,3] + 0.71 * headsize.std[,4]

# ��������

girth1 <- -0.69 * headsize.std[,1] -  0.72 * headsize.std[,2]
girth2 <-  0.74 * headsize.std[,3] + 0.67 * headsize.std[,4]
shape1 <- -0.71 * headsize.std[,1] + 0.71 * headsize.std[,2]
shape2 <- -0.70 * headsize.std[,3] + 0.71 * headsize.std[,4]


cor(girth1,girth2)
cor(shape1,shape2)
#
par(mfrow=c(1,2))
plot(girth1,girth2)
plot(shape1,shape2)
#

cor(girth1,shape1)
cor(girth2,shape2)
## cor(girth1,shape2)
## cor(girth2,shape1)
#
######## p. 165
r22 <- matrix(c(1.0,0.044,-0.106,-0.180,0.044,1.0,-0.208,-0.192,-0.106,-0.208,1.0,0.492,-0.180,-0.192,0.492,1.0),ncol = 4, byrow = T )
r22
r11 <- matrix(c(1.0, 0.212, 0.212, 1.0),ncol = 2, byrow =T )
r11
r12 <- matrix(c(0.124,-0.164,-0.101,-0.158,0.098,0.308,-0.270,-0.183),ncol = 4, byrow = T)
r12
r21 <- t(r12)
r21
## ## #######3
##  r22 <- matrix(c(1.0,0.044,-0.106,-0.180,0.044,1.0,-0.208,-0.192,-0.106,-0.208,1.0,0.492,-0.180,-0.192,0.492,1.0),ncol = 4)
## ## r22
##  r11 <- matrix(c(1.0, 0.212, 0.212, 1.0),ncol = 2)
## ## r11
##  r12 <- matrix(c(0.124,-0.164,-0.101,-0.158,0.098,0.308,-0.270,-0.183),ncol = 4)
## ## r12
##  r21 <- t(r12)
## ## r21

#
E1 <- solve(r11) %*% r12 %*% solve(r22) %*% r21
E2 <- solve(r22) %*% r21 %*% solve(r11) %*% r12
#
E1
E2
#
eigen(E1)
eigen(E2)

eigen(E1)$values
eigen(E2)$values

sqrt(eigen(E1)$values)
sqrt(eigen(E2)$values)

t(eigen(E1)$vectors)
t(eigen(E2)$vectors)




##############################################################
#
#
#                           �� 9 ��
#
#                  ��������f�[�^�̕���
#
#
################################################# chapter09 ###

timber<-source("Data/chap9timber.dat")$value
# by Everitt
#

 #
 x<-c(0.0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0,1.2,1.4,1.6,1.8)
 slippage<-rep(x,8)
 loads<-as.vector(t(timber))
 specimen<-rep(1:8,rep(15,8))
 #
 timber.dat<-data.frame(specimen,slippage,as.vector(t(timber)))
 #
 attach(timber.dat)
 #
 library(nlme)
 timber.lme<-lme(loads~slippage,random=~1|specimen,data=timber.dat,method="ML")

 summary(timber.lme)

###########3
x<-c(0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.2, 1.4, 1.6, 1.8)
x
slippage<-rep(x,8)
slippage
loads<-as.vector(t(timber))
loads
specimen<-rep(1:8,rep(15,8))
specimen
#
# timber.dat<-data.frame(specimen,slippage,as.vector(t(timber)))
timber.dat<-data.frame(specimen,slippage, loads)
timber.dat
#
attach(timber.dat)
#timber.dat<-data.frame(specimen,slippage,as.vector(t(timber)))
timber.dat
library(nlme)
#random intercept model
timber.lme <- lme(loads ~ slippage, random = ~1|specimen, data = timber.dat, method="ML")
#
#timber.lme <- lme(loads ~ slippage, random = ~1|specimen, data = timber.dat,  method="REML")
#
summary(timber.lme)
######## �ԈႢ # timber.lme <- lme(loads ~ slippage, random = ~1, data = timber.dat, method="ML")
######## �ԈႢ # timber.lme <- lme(loads ~ 1, random = ~1|specimen, data = timber.dat, method="ML")
#
#random intercept and slope model
timber.lme1 <- lme(loads ~ slippage, random = ~slippage|specimen, data=timber.dat, method="ML")
## timber.lme1 <- lme(loads ~ slippage, random = ~specimen|slippage, data=timber.dat, method="ML")
#timber.lme1 <- lme(loads ~ slippage, random = ~1|slippage/specimen, data=timber.dat, method="ML")
######  �ԈႢ ## timber.lme1 <- lme(loads ~ slippage, random = ~slippage/specimen, data=timber.dat, method="ML")

anova(timber.lme,timber.lme1)
summary(timber.lme1)


## Tab9.5
timber.lme2 <- lme(loads ~ slippage + I(slippage * slippage), random = ~1|specimen, data=timber.dat, method="ML")

summary(timber.lme2)
anova(timber.lme,timber.lme2)
summary(timber.lme)


###################################################################
## library(lme4)
## timber.lmer <- lmer(loads ~ slippage + (1|specimen), data = timber.dat, method="ML")
## #
## timber.lmer1 <- lmer(loads ~ slippage + (slippage|specimen), data=timber.dat, method="ML")
## # anova(timber.lmer,timber.lmer1)
###################################################################

summary(timber.lme)
##############

# predictions <- matrix(predict(timber.lme1),ncol=15,byrow=T)

predictions <- matrix(predict(timber.lme),ncol=15,byrow=T)

########
predictions
par(mfrow=c(1,2))
matplot(x,t(timber),type="l",col=1,xlab="Slippage",ylab="Load",lty=1,ylim=c(0,25))
title("(a)")
matplot(x,t(predictions),type="l",col=1,xlab="Slippage",ylab="Load",lty=1,ylim=c(0,25))
title("(b)")
#


#### ������
timber.lme2<-lme(loads ~ slippage + I(slippage * slippage),
random = ~ 1|specimen, data=timber.dat, method="ML")
summary(timber.lme2)
anova(timber.lme,timber.lme2)
#
predictions<-matrix(predict(timber.lme2),ncol=15,byrow=T)
predictions
par(mfrow=c(1,2))
matplot(x,t(timber),type="l",col=1,xlab="Slippage",ylab="Load",lty=1,ylim=c(0,25))
title("(a)")
matplot(x,t(predictions),type="l",col=1,xlab="Slippage",ylab="Load",lty=1,ylim=c(0,25))
title("(b)")
#





#########      plasma       ##########

plasma<-source("Data/chap9plasma.dat")$value
#

par(mfrow=c(1,2))

matplot(matrix(c(0.0,0.5,1.0,1.5,2.0,3.0,4.0,5.0),ncol=1), 
t(plasma[1:13,]),type="l",col=1,lty=1, 
xlab="Time (hours after oral glucose challenge)",ylab="Plasma inorganic phosphate",ylim=c(1,7)) 
title("Control") 
matplot(matrix(c(0.0,0.5,1.0,1.5,2.0,3.0,4.0,5.0),ncol=1), 
t(plasma[14:33,]),type="l",col=1,lty=1, 
xlab="Time (hours after glucose challenge)",ylab="Plasma inorganic phosphate",ylim=c(1,7)) 
title("Obese")
## #

##
options(X11fonts = c("-alias-mincho-%s-%s-*-*-%d-*-*-*-*-*-*-*","-adobe-symbol-*-*-*-*-%d-*-*-*-*-*-*-*"))
 ps.options(family= "Japan1Ryumin") # Windows �ł͂����������s

## options(X11fonts = c("-alias-gothic-%s-%s-*-*-%d-*-*-*-*-*-*-*", "-adobe-symbol-*-*-*-*-%d-*-*-*-*-*-*-*"))
par(mfrow=c(1,2))
matplot(matrix(c(0.0,0.5,1.0,1.5,2.0,3.0,4.0,5.0),ncol=1), 
t(plasma[1:13,]),type="l",col=1,lty=1, 
xlab="�o�ߎ��ԁi�o���u�h�E�����׎�����́j",ylab="�������̖��@�����_",ylim=c(1,7)) 
title("�ΏƌQ") 
matplot(matrix(c(0.0,0.5,1.0,1.5,2.0,3.0,4.0,5.0),ncol=1), 
t(plasma[14:33,]),type="l",col=1,lty=1, 
xlab="�o�ߎ��ԁi�o���u�h�E�����׎�����́j",ylab="�������̖��@�����_",ylim=c(1,7)) 
title("�얞�ǌQ")
## 


##########3

pdf(file = "figure9.3.jp2.pdf")
par(mfrow=c(1,2))
matplot(matrix(c(0.0,0.5,1.0,1.5,2.0,3.0,4.0,5.0),ncol=1), 
t(plasma[1:13,]),type="l",col=1,lty=1, 
xlab="�o�ߎ��ԁi�o���u�h�E�����׎�����́j",ylab="�������̖��@�����_",ylim=c(1,7)) 
title("�ΏƌQ") 
matplot(matrix(c(0.0,0.5,1.0,1.5,2.0,3.0,4.0,5.0),ncol=1), 
t(plasma[14:33,]),type="l",col=1,lty=1, 
xlab="�o�ߎ��ԁi�o���u�h�E�����׎�����́j",ylab="�������̖��@�����_",ylim=c(1,7)) 
title("�얞�ǌQ")
dev.off()
##

# ############################################
# 
pairs(plasma[1:13,])
#

############################################
pairs(plasma[14:33,])

############################################
# 
# 
# 
group<-rep(c(0,1),c(104,160))
group
# 
time<-c(0.0,0.5,1.0,1.5,2.0,3.0,4.0,5.0) 
time<-rep(time,33)
time
# 
subject<-rep(1:33,rep(8,33))
subject

plasma.dat<-cbind(subject,time,group,as.vector(t(plasma)))
plasma.dat

dimnames(plasma.dat)<-list(NULL,c("Subject","Time","Group","Plasma"))
plasma.dat
# 
plasma.df<-data.frame(plasma.dat)
plasma.df

plasma.df$Group<-factor(plasma.df$Group,levels=c(0,1),labels=c("Control","Obese"))
plasma.df
# 
attach(plasma.df) 
#
library(nlme)
# Tab9.7
plasma.lme1<-lme(Plasma~Time+I(Time*Time)+Group,random=~Time|Subject, data=plasma.df,method="ML") 
summary(plasma.lme1)

contrasts(Group)
#contrasts(plasma.lme1)
# 
#multiple regression model-independence model % Tab9.8
summary(lm(Plasma~Time+I(Time*Time)+Group,data=plasma.df)) 
# 
# 
predictions<-matrix(predict(plasma.lme1),ncol=8,byrow=T) 
par(mfrow=c(1,2)) 
matplot(matrix(c(0.0,0.5,1,1.5,2,3,4,5),ncol=1), 
t(predictions[1:13,]),type="l",lty=1,col=1, 
xlab="Time (hours after glucose challenge)",ylab="Plasma inorganic phosphate",ylim=c(1,7)) 
title("Control") 
matplot(matrix(c(0.0,0.5,1,1.5,2,3,4,5),ncol=1), 
t(predictions[14:33,]),type="l",lty=1,col=1, 
xlab="Time (hours after glucose challenge)",ylab="Plasma inorganic phosphate",ylim=c(1,7)) 
title("Obese") 
#

# p.187
##########
options(X11fonts = c("-alias-mincho-%s-%s-*-*-%d-*-*-*-*-*-*-*","-adobe-symbol-*-*-*-*-%d-*-*-*-*-*-*-*"))
 ps.options(family= "Japan1Ryumin") # Windows �ł͂����������s
#
predictions<-matrix(predict(plasma.lme1),ncol=8,byrow=T) 
par(mfrow=c(1,2)) 
matplot(matrix(c(0.0,0.5,1,1.5,2,3,4,5),ncol=1), 
t(predictions[1:13,]),type="l",lty=1,col=1, 
xlab="�o�ߎ��ԁi�o���u�h�E�����׎�����́j",ylab="�������̖��@�����_",ylim=c(1,7)) 
title("�ΏƌQ") 
matplot(matrix(c(0.0,0.5,1,1.5,2,3,4,5),ncol=1), 
t(predictions[14:33,]),type="l",lty=1,col=1, 
xlab="�o�ߎ��ԁi�o���u�h�E�����׎�����́j",ylab="�������̖��@�����_",ylim=c(1,7)) 
title("�얞�ǌQ")

# p.187

###
predictions<-matrix(predict(plasma.lme1),ncol=8,byrow=T) 
par(mfrow=c(1,2)) 
matplot(matrix(c(0.0,0.5,1,1.5,2,3,4,5),ncol=1), 
t(predictions[1:13,]),type="l",lty=1,col=1, 
xlab="�o�ߎ��ԁi�o���u�h�E�����׎�����́j",ylab="�������̖��@�����_",ylim=c(1,7)) 
title("�ΏƌQ") 
matplot(matrix(c(0.0,0.5,1,1.5,2,3,4,5),ncol=1), 
t(predictions[14:33,]),type="l",lty=1,col=1, 
xlab="�o�ߎ��ԁi�o���u�h�E�����׎�����́j",ylab="�������̖��@�����_",ylim=c(1,7)) 
title("�얞�ǌQ")
dev.off()

##############################################################
plasma.lme2<-lme(Plasma~Time*Group+I(Time*Time),random=~Time|Subject, 
data=plasma.df,method="ML") 
anova(plasma.lme1,plasma.lme2) 
# Tab9.9
summary(plasma.lme2) 
#
predictions<-matrix(predict(plasma.lme2),ncol=8,byrow=T)


par(mfrow=c(1,2)) 
matplot(matrix(c(0.0,0.5,1,1.5,2,3,4,5),ncol=1), 
t(predictions[1:13,]),type="l",lty=1,col=1, 
xlab="Time (hours after glucose challenge)",ylab="Plasma inorganic phosphate",ylim=c(1,7)) 
title("Control") 
matplot(matrix(c(0.0,0.5,1,1.5,2,3,4,5),ncol=1), 
t(predictions[14:33,]),type="l",lty=1,col=1, 
xlab="Time (hours after glucose challenge)",ylab="Plasma inorganic phosphate",ylim=c(1,7)) 
title("Obese") 
# p.189
#
##########
options(X11fonts = c("-alias-mincho-%s-%s-*-*-%d-*-*-*-*-*-*-*","-adobe-symbol-*-*-*-*-%d-*-*-*-*-*-*-*"))
 ps.options(family= "Japan1Ryumin") # Windows �ł͂����������s
#

predictions<-matrix(predict(plasma.lme2),ncol=8,byrow=T) 
par(mfrow=c(1,2)) 
matplot(matrix(c(0.0,0.5,1,1.5,2,3,4,5),ncol=1), 
t(predictions[1:13,]),type="l",lty=1,col=1, 
xlab="�o�ߎ��ԁi�o���u�h�E�����׎�����́j",ylab="�������̖��@�����_",ylim=c(1,7)) 
title("�ΏƌQ") 
matplot(matrix(c(0.0,0.5,1,1.5,2,3,4,5),ncol=1), 
t(predictions[14:33,]),type="l",lty=1,col=1, 
xlab="�o�ߎ��ԁi�o���u�h�E�����׎�����́j",ylab="�������̖��@�����_",ylim=c(1,7)) 
title("�얞�ǌQ")


# p.189
###
pdf("figure9.7.jp2.pdf")
predictions<-matrix(predict(plasma.lme2),ncol=8,byrow=T) 
par(mfrow=c(1,2)) 
matplot(matrix(c(0.0,0.5,1,1.5,2,3,4,5),ncol=1), 
t(predictions[1:13,]),type="l",lty=1,col=1, 
xlab="�o�ߎ��ԁi�o���u�h�E�����׎�����́j",ylab="�������̖��@�����_",ylim=c(1,7)) 
title("�ΏƌQ") 
matplot(matrix(c(0.0,0.5,1,1.5,2,3,4,5),ncol=1), 
t(predictions[14:33,]),type="l",lty=1,col=1, 
xlab="�o�ߎ��ԁi�o���u�h�E�����׎�����́j",ylab="�������̖��@�����_",ylim=c(1,7)) 
title("�얞�ǌQ")
dev.off()

##############################################################
# 
res.int<-random.effects(plasma.lme2)[,1] 
res.int 
res.slope<-random.effects(plasma.lme2)[,2]

par(mfrow=c(1,3)) 
qqnorm(res.int,ylab="Estimated random intercepts",main="Random intercepts") 
qqnorm(res.slope,ylab="Estimated random slopes",main="Random slopes") 
resids<-resid(plasma.lme2) 
qqnorm(resids,ylab="Estimated residuals",main="Residuals") 
# 
#
# p.190
######################################
##########
options(X11fonts = c("-alias-mincho-%s-%s-*-*-%d-*-*-*-*-*-*-*","-adobe-symbol-*-*-*-*-%d-*-*-*-*-*-*-*"))
 ps.options(family= "Japan1Ryumin") # Windows �ł͂����������s
#
res.int<-random.effects(plasma.lme2)[,1] 
res.int 
res.slope<-random.effects(plasma.lme2)[,2] 
par(mfrow=c(1,3)) 
qqnorm(res.int,ylab="�����_���ؕЂ̐���l",main="�����_���ؕ�",xlab ="�W�����K���z�̕��ʓ_") 
qqnorm(res.slope,ylab="�����_���X���̐���l",main="�����_���X��",xlab ="�W�����K���z�̕��ʓ_") 
resids<-resid(plasma.lme2) 
qqnorm(resids,ylab="�c���̐���l",main="�c��",xlab ="�W�����K���z�̕��ʓ_") 
# 
#
# p.190

###
pdf(file = "figure9.8.jp2.pdf")
par(mfrow=c(1,3)) 
qqnorm(res.int,ylab="�����_���ؕЂ̐���l",main="�����_���ؕ�",xlab ="�W�����K���z�̕��ʓ_") 
qqnorm(res.slope,ylab="�����_���X���̐���l",main="�����_���X��",xlab ="�W�����K���z�̕��ʓ_") 
resids<-resid(plasma.lme2) 
qqnorm(resids,ylab="�c���̐���l",main="�c��",xlab ="�W�����K���z�̕��ʓ_") 
#
dev.off()
#


##############################################################



btb.data<-source("Data/chap9btb.dat")$value 
# 
attach(btb.data)
# 
par(mfrow=c(2,1)) 
boxplot(btb.data[Treatment=="TAU",4],btb.data[Treatment=="TAU",5],btb.data[Treatment=="TAU",6], btb.data[Treatment=="TAU",7],btb.data[Treatment=="TAU",8],names=c("BDIpre","BDI2m","BDI4m","BDI6m", "BDI8m"),ylab="BDI", xlab="Visit",col= "white") 
title("TAU")

boxplot(btb.data[Treatment=="BtheB",4],btb.data[Treatment=="BtheB",5],btb.data[Treatment=="BtheB",6], 
btb.data[Treatment=="BtheB",7],btb.data[Treatment=="BtheB",8],names=c("BDIpre","BDI2m","BDI4m","BDI6m", "BDI8m"),ylab="BDI", xlab="Visit",col="white") 
title("BtheB") 
# p.195
### ���{��
##########
options(X11fonts = c("-alias-mincho-%s-%s-*-*-%d-*-*-*-*-*-*-*","-adobe-symbol-*-*-*-*-%d-*-*-*-*-*-*-*"))
 ps.options(family= "Japan1Ryumin") # Windows �ł͂����������s
###
par(mfrow=c(2,1)) 
boxplot(btb.data[Treatment=="TAU",4],btb.data[Treatment=="TAU",5],btb.data[Treatment=="TAU",6], btb.data[Treatment=="TAU",7],btb.data[Treatment=="TAU",8],names=c("BDIpre","BDI2m","BDI4m","BDI6m", "BDI8m"),ylab="BDI", xlab="�f�@����",col= "white") 
title("TAU")

boxplot(btb.data[Treatment=="BtheB",4],btb.data[Treatment=="BtheB",5],btb.data[Treatment=="BtheB",6], 
btb.data[Treatment=="BtheB",7],btb.data[Treatment=="BtheB",8],names=c("BDIpre","BDI2m","BDI4m","BDI6m", "BDI8m"),ylab="BDI", xlab="�f�@����",col="white") 
title("BtheB")



# p.195

###
pdf( file = "figure9.9.jp2.pdf")
par(mfrow=c(2,1)) 
boxplot(btb.data[Treatment=="TAU",4],btb.data[Treatment=="TAU",5],btb.data[Treatment=="TAU",6], btb.data[Treatment=="TAU",7],btb.data[Treatment=="TAU",8],names=c("BDIpre","BDI2m","BDI4m","BDI6m", "BDI8m"),ylab="BDI", xlab="�f�@����",col= "white") 
title("TAU")

boxplot(btb.data[Treatment=="BtheB",4],btb.data[Treatment=="BtheB",5],btb.data[Treatment=="BtheB",6], 
btb.data[Treatment=="BtheB",7],btb.data[Treatment=="BtheB",8],names=c("BDIpre","BDI2m","BDI4m","BDI6m", "BDI8m"),ylab="BDI", xlab="�f�@����",col="white") 
title("BtheB")
dev.off()

##############################################################
# 
# 
# 
# 
n <- length(btb.data[, 1]) 
# 
BDI <- as.vector(t(btb.data[,c(5, 6, 7, 8)])) 
# 
treat<-rep(btb.data[,3],rep(4,n)) 
subject<-rep(1:n,rep(4,n)) 
preBDI<-rep(btb.data[,4],rep(4,n)) 
drug<-rep(btb.data[,1],rep(4,n)) 
length<-rep(btb.data[,2],rep(4,n)) 
time<-rep(c(2,4,6,8),n) 
# 
# 
btb.bdi<-data.frame(subject,treat,drug,length,preBDI,time,BDI) 
# 
attach(btb.bdi) 
# 
#
library(nlme)
#
btbbdi.fit1<-lme(BDI~preBDI+time+treat+drug+length,method="ML", 
random=~1|subject,data=btb.bdi,na.action=na.omit) 
# 
btbbdi.fit2<-lme(BDI~preBDI+time+treat+drug+length,method="ML", random=~time|subject,data=btb.bdi,na.action=na.omit) 
anova(btbbdi.fit2,btbbdi.fit1) 
# 
summary(btbbdi.fit1) 
# 
 x <- 3 == 4
