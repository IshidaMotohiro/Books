getwd ()

setwd ("D:/data") # Dドライブのdataフォルダに移動

1 + 2

install.packages ("rgl")
library (rgl)

demo (rgl)
