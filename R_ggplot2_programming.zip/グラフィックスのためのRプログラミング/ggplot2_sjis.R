#  this file is encoded in SJIS (CP932)f

# 2015 05 26  ver.5
############################################################
#   �O���t�B�b�N�X�̂��߂̂q�v���O���~���O�@ggplot2����       #
#      �g�D�E�B�b�J���^���@�Γc��L�^��@�Γc�a�}�^��         #
#                 �V���v�����K�[�E�W���p��                  #
#                        2011�N07��                        #
#                  ISBN 978-4-431-10250-2                  #
#                                                          #
############################################################

# ���{��̕\���ɕK�v�Ȑݒ�
# ���{��̕\���ɕK�v�Ȑݒ�
library(ggplot2)

if (.Platform$pkgType == "mac.binary"){
    quartzFonts(HiraMaru=quartzFont(rep("HiraMaruProN-W4", 4)))
    theme_set(theme_grey(base_family = "HiraMaru"))
} else if (.Platform$pkgType == "win.binary"){
    windowsFonts(JP1=windowsFont("MS Gothic"),JP2=windowsFont("MS Mincho"),JP3=windowsFont("Meiryo"))
    theme_set(theme_grey(base_family = "JP1"))
}else {
    # $ fc-list :lang=ja
    # theme_set(theme_gray(base_size = 12, base_family="TakaoPGothic"))
}



  ## ## ggplot2 �̏o�͒����D���x����v���b�g�_�Ȃǂ��C���Зp�Ɋg�傷��(�����f�ڃR�[�h�̂܂܂ł͏���������)
# ��{�� + theme_bw(base_size = 18) �ȂǂőΉ��ł���͂������A�ׂ����ݒ肵������΁A�ȉ��̂悤�Ɏ��s����B���� theme_classic(base_size = 12, base_family = "")#�Ȃǂ����p�\

  ## #####
  ## oldTheme <- theme_update(
  ##                          axis.title.x = element_text(size = 26, vjust = 0.5), # �������x���T�C�Y
  ##                          axis.title.y = element_text(size =26, vjust = 0.5, angle = 90),# y�����x��
  ##                          legend.text =  element_text(size = 26), # �}��
  ##                          legend.key.size = grid::unit(3.0, "lines"),
  ##                          legend.title = element_text(face = "bold", size = 26, hjust = 0),
  ##                          axis.text.x = element_text(colour = "grey50", size = 22, vjust = 1,     lineheight = 0.9),#x���ڐ����x��
  ##                          axis.text.y = element_text(colour = "grey50", size = 22, hjust = 1,  lineheight = 0.9),#y���ڐ����x��
  ##                          strip.text.x = element_text(size = 26), #�X�g���b�v���̖}��T�C�Y
  ##                          strip.text.y = element_text(size = 26, angle = -90),
  ##                          plot.title = element_text(size = 28)
  ##                          )
  ## ##


  ## ## ��L�̐ݒ�����ۂɓK�p
  ## geomOld <- update_geom_defaults ("point", aes(size= 8 ))
  ####
  ## ���Ɓiggplot2�̃f�t�H���g�j�ɖ߂��ꍇ
  ## theme_update (oldTheme)




############################################################
#                     �� 2 �̓X�N���v�g                     #
############################################################




library(ggplot2)

# 2.2
# p.11 
set.seed(1410) ## �����𒲐����Ē��o�f�[�^���Č��\�ɂ��܂�
dsmall <- diamonds[sample(nrow(diamonds), 100), ]

# p.11 �}
qplot(carat, price, data = diamonds)


##########
# p.12 �} a
qplot(log(carat), log(price), data = diamonds)


##########
# p.12 �}  b
qplot(carat, x * y * z, data = diamonds)


# # 2.4  

# p.13 
# �} 2.2a
qplot(carat, price, data = dsmall, colour = color)
# �} 2.2b
qplot(carat, price, data = dsmall, shape = cut)
#


# p.14 
# �}2.3a
qplot (carat, price, data = diamonds, alpha = I(1/10))
# �}2.3b
qplot(carat, price, data = diamonds, alpha = I(1/100))
# �}2.3c
qplot(carat, price, data = diamonds, alpha = I(1/200))
#

# 2.5.1
# p.15 
# �}2.4a
qplot(carat, price, data = dsmall, geom = c("point", "smooth"))

# �}2.4b
qplot(carat, price, data = diamonds, geom = c("point", "smooth"))


# p.16 
# �}2.5a
qplot(carat, price, data = dsmall, geom = c("point", "smooth"), 
  span = 0.2)

# �}2.5b
qplot(carat, price, data = dsmall, geom = c("point", "smooth"), 
  span = 1)



library(mgcv)

# p.17 
# �}2.6a
qplot(carat, price, data = dsmall, geom = c("point", "smooth"), 
  method = "gam", formula = y ~ s(x))

# �}2.6b
qplot(carat, price, data = dsmall, geom = c("point", "smooth"), 
  method = "gam", formula = y ~ s(x, bs = "cs"))
 

library(splines)
# �}2.7a
qplot(carat, price, data = dsmall, geom = c("point", "smooth"), 
  method = "lm")
# �}2.7b
qplot(carat, price, data = dsmall, geom = c("point", "smooth"), 
  method = "lm", formula = y ~ ns(x,5))

# p.18
# �}2.8a
qplot(color, price / carat, data = diamonds, geom = "jitter")

# �}2.8b
qplot(color, price / carat, data = diamonds, geom = "boxplot")

# p.19
# �}2.9a
qplot(color, price / carat, data = diamonds, geom = "jitter",
 alpha = I(1 / 5))

# �}2.9b
qplot(color, price / carat, data = diamonds, geom = "jitter",
 alpha = I(1 / 50))

# �}2.9c.ps
qplot(color, price / carat, data = diamonds, geom = "jitter",
 alpha = I(1 / 200))

#
# p.20 
# �}2.10a
qplot(carat, data = diamonds, geom = "histogram")

# �}2.10b
qplot(carat, data = diamonds, geom = "density")


# p.21 
# �}2.11a
qplot(carat, data = diamonds, geom = "histogram", binwidth = 1, 
  xlim = c(0,3))

# �}2.11b
qplot(carat, data = diamonds, geom = "histogram", binwidth = 0.1,
  xlim = c(0,3))

# �}2.11c.ps
qplot(carat, data = diamonds, geom = "histogram", binwidth = 0.01,
  xlim = c(0,3))



# �}2.12a
qplot(carat, data = diamonds, geom = "density", colour = color)

# �}2.12b
qplot(carat, data = diamonds, geom = "histogram", fill = color)


                                        # p.22 
# �}2.13a
qplot(color, data = diamonds, geom = "bar")

# �}2.13b
qplot(color, data = diamonds, geom = "bar", weight = carat) +
  scale_y_continuous("carat")

# p.23 
# �}2.14a
qplot(date, unemploy / pop, data = economics, geom = "line")

# �}2.14b.ps
qplot(date, uempmed, data = economics, geom = "line")


# p.23
year <- function(x) as.POSIXlt(x)$year + 1900

# �}2.15a
qplot(unemploy / pop, uempmed, data = economics, 
   geom = c("point", "path"))

# �}2.15b.ps
qplot(unemploy / pop, uempmed, data = economics, 
  geom = "path", colour = year(date)) + scale_area()

# p.24 
# �}2.16a
qplot(carat, data = diamonds, facets = color ~ ., 
  geom = "histogram", binwidth = 0.1, xlim = c(0, 3))

# �}2.16b
qplot(carat, ..density.., data = diamonds, facets = color ~ .,
  geom = "histogram", binwidth = 0.1, xlim = c(0, 3))



# 2.7 

# p.26 �} a
qplot(
  carat, price, data = dsmall, 
  xlab = "Price ($)", ylab = "Weight (carats)",  
  main = "���i�Əd�ʂ̊֌W"# main = "Price-weight relationship"
)


# p.26 �} b
qplot(
   carat, price/carat, data = dsmall, 
   ylab = expression(frac(price,carat)), 
   xlab = "Weight (carats)",  
   main="�_�C�������h���o�W�{", # main="Small diamonds", 
   xlim = c(.2,1)
)


# p.27 �} c

qplot(carat, price, data = dsmall, log = "xy")




############################################################
#                          ��O��                          #
#                       {���@�̏K��}                       #
############################################################

library(ggplot2)


# 3.3

# �} 3.1
qplot(displ, hwy, data = mpg, colour = factor(cyl))

# p.33 
# �}3.2a
# 'opts' ���\�b�h�� ggplot2 �� 0.9.2 �ȍ~�͗��p�ł��܂���D���� 'theme' ���\�b�h���g���܂�
qplot(displ, hwy, data=mpg, colour=factor(cyl),
      geom="line") + ## opts(drop = "legend_box")
  theme(legend.box = NULL)

# �}3.2b
qplot(displ, hwy, data=mpg, colour=factor(cyl), geom="bar", 
  stat="identity", position = "identity") + # #  opts(drop = "legend_box")
  theme(legend.box = NULL)

# p.34
# �}3.3
qplot(displ, hwy, data=mpg, colour=factor(cyl)) +
  geom_smooth(data= subset(mpg, cyl != 5), method="lm")

# p.35
# �} 3.4

hcl <- expand.grid(x = seq(-1, 1, length = 100), y = seq(-1, 1, length=100))
hcl <- subset(hcl, x^2 + y^2 < 1)

hcl <- within(hcl, {
  r <- sqrt(x^2 + y^2)
  c <- 100 * r
  h <- 180 / pi * atan2(x, y)
  l <- 65
})

hcl$colour <- hcl(hcl$h, hcl$c, hcl$l)

with(hcl, plot(x, y, col=colour, pch=20, cex=3))

# 3.4
# p.37 
# �} 3.6
qplot(displ, hwy, data=mpg, facets = . ~ year) + geom_smooth()


# 3.5 
x <- 1:10
y <- factor(letters[1:5])

qp <- qplot(x, x, size = x) #+ ## opts(keep = "legend_box")
 
# �} 3.8 a
qp

# �} 3.8 b
qplot(x, x, 1:10, colour = x) #+ opts(keep = "legend_box")

# �} 3.8 c
qplot(y, y, 1:10, shape = y) # + opts(keep = "legend_box")
# �} 3.8 d
qplot(y, y, 1:10, colour = y, width = .5) # + opts(keep = "legend_box")


# p.42 
x1 <- c(1,10)
y1 <- c(1, 5)
p <- qplot(x1, y1, geom="blank", xlab=NULL, ylab=NULL) + theme_bw()

# �} 3.9
p

p + coord_trans(y="log10")

p + coord_polar()
#

# 3.6
# p.43 

p <- qplot(displ, hwy, data = mpg, colour = factor(cyl))
summary(p)
# 
save(p, file = "plot.rdata")
#
load("plot.rdata")
# 
ggsave("plot.png", width = 5, height = 5)







############################################################
#                  ��l�� ���C���[ layers                  #
############################################################

library(ggplot2)


# 4.2
# p.46
p <- ggplot(diamonds, aes(carat, price, colour = cut))

print(p) # ���̒i�K�ł͉����\������Ȃ�

# 4.3
p <- p + layer(geom = "point")
print(p) 


# p.47 
p <- ggplot(diamonds, aes(x = carat))
p <- p + layer(
  geom = "bar", 
  geom_params = list(fill = "steelblue"),
  stat = "bin",
  stat_params = list(binwidth = 2)
)

p

# p <- p + geom_histogram(binwidth = 2, fill = "steelblue")

      #  geom_XXX(mapping, data, ..., geom, position)
      #  stat_XXX(mapping, data, ..., stat, position)

# p.48 
ggplot(msleep, aes(sleep_rem / sleep_total, awake)) + 
  geom_point()

# 
qplot(sleep_rem / sleep_total, awake, data = msleep)

# 
qplot(sleep_rem / sleep_total, awake, data = msleep) + 
  geom_smooth()
#

# p.49
qplot(sleep_rem / sleep_total, awake, data = msleep, 
  geom = c("point", "smooth"))
#

ggplot(msleep, aes(sleep_rem / sleep_total, awake)) + 
  geom_point() + geom_smooth()

p <- ggplot(msleep, aes(sleep_rem / sleep_total, awake))
summary(p)

p <- p + geom_point()
summary(p)

# p.50

bestfit <- geom_smooth(method = "lm", se = F,  alpha = 0.5, color = "steelblue", size = 2)# colour = alpha("steelblue", 0.5)

qplot(sleep_rem, sleep_total, data = msleep) + bestfit

qplot(awake, brainwt, data = msleep, log = "y") + bestfit

qplot(bodywt, brainwt, data = msleep, log = "xy") + bestfit


# 4.4
# p.50
p <- ggplot(mtcars, aes(mpg, wt, colour = cyl)) + geom_point()
p
mtcars <- transform(mtcars, mpg = mpg ^ 2)
p %+% mtcars


# 4.5

   aes(x = weight, y = height, colour = age)

   aes(weight, height, colour = sqrt(age))

# p.52 
p <- ggplot(mtcars)
summary(p)

p <- p + aes(wt, hp)
summary(p)


#
p <- ggplot(mtcars, aes(x = mpg, y = wt))
# p.52 �}
p + geom_point()

# 4.5.1
# �} 4.1 a
p + geom_point(aes(colour = factor(cyl)))

# �} 4.1 b
p + geom_point(aes(y = disp))


# 4.5.2
# p.54
p <- ggplot (mtcars, aes(mpg, wt))

# �}4.2a
p + geom_point(colour = "darkblue")

# �}4.2b
p + geom_point(aes(colour = "darkblue"))

  # qplot(mpg, wt, data=mtcars, colour = I("darkblue"))
  # qplot(mpg, wt, data=mtcars, colour = "darkblue")


# p.56
data (Oxboys, package="nlme")

p1 <- ggplot (Oxboys, aes(age, height, group = Subject)) +
  geom_line()
# �} 4.3 a
p1

p2 <- ggplot(Oxboys, aes(age, height, group = 1)) +   geom_line()
# �}4.3b
p2

  # qplot (age, height, data=Oxboys, group = Subject, geom="line")
  # qplot (age, height, data=Oxboys, geom="line")


# p.56 
# �}4.4a
p1 + geom_smooth (aes(group = Subject), method = "lm", se = F)

# �}4.4b
p1 + geom_smooth (aes(group = 1), method = "lm", size = 2, se = F)


# p.57 
boysbox <- ggplot(Oxboys, aes(Occasion, height)) + geom_boxplot()
# �}4.5a
boysbox

#�}4.5b
boysbox + geom_line(aes(group = Subject), colour = "#3366FF")

  # qplot(Occasion, height, data=Oxboys, geom="boxplot")
  # qplot(Occasion, height, data=Oxboys, geom="boxplot") +
  #  geom_line(aes(group = Subject), colour="#3366FF")


# p.58

df <- data.frame(x = 1:3, y = 1:3, colour = c(1,3,5))

# �}4.6a
qplot(x, y, data = df, colour = factor(colour), size = I(5)) + 
  geom_line(aes(group = 1), size = 2)

# �}4.6b # 0.9.3�ȍ~�̃o�[�W�����ł́C��������і|��Ɍf�ڂ��ꂽ�}�Ƃ͈قȂ�C
# �}�̖}�����Ԃ��ꂽ�O���f�[�V�����Ƃ��ĕ\������܂�
qplot(x, y, data = df, colour = colour, size = I(5)) + geom_line(size = 2)# colour=colour,

# p.59
xgrid <- with(df, seq(min(x), max(x), length = 50))

interp <- data.frame(
  x = xgrid,
  y = approx(df$x, df$y, xout = xgrid)$y,
  colour = approx(df$x, df$colour, xout = xgrid)$y  
)

# p.59 �}
qplot(x, y, data = df, colour = colour, size = I(5)) + 
  geom_line(data = interp, size = 2)

# p.60
# �}4.7a
qplot (color, data = diamonds)

# �}4.7b
qplot(color, data = diamonds, fill = cut)



# 4.7
# p.64
ggplot(diamonds, aes(carat)) + 
  geom_histogram(aes(y = ..density..), binwidth = 0.1)


  # ggplot(diamonds, aes(carat)) + 
  #   geom_histogram(binwidth = 0.1)

  # qplot(carat, ..density.., data = diamonds, geom = "histogram", 
  #    binwidth = 0.1)

  # qplot (carat, data = diamonds, geom = "histogram",   binwidth = 0.1)


# 4.8 

dplot <- ggplot(diamonds, aes(clarity, fill = cut))

# p.65
# �}4.8a
dplot + geom_bar(position = "stack")

# �}4.8b
dplot + geom_bar(position = "fill")

# �}4.8c
dplot + geom_bar(position = "dodge")


# p.66 
# �}4.9a
dplot + geom_bar(position = "identity")

# �}4.9b
qplot(clarity, data = diamonds, geom = "line", colour = cut, stat = "bin", group = cut)


# 4.9

d <- ggplot(diamonds, aes(carat)) + xlim(0, 3)

# p.67
# �} 4.10 a
d + stat_bin(aes(ymax = ..count..), binwidth = 0.1, geom = "area")

# �} 4.10 b
d + stat_bin(
  aes(size = ..density..), binwidth = 0.1, 
  geom = "point", position="identity"
)


# �} 4.10 c
d + stat_bin(
  aes(y = 1, fill = ..count..), binwidth = 0.1, 
  geom = "tile", position="identity"
)


# 4.9.3 
# p.68
require(nlme, quiet = TRUE, warn.conflicts = FALSE)

model <- lme(height ~ age, data = Oxboys, 
 random = ~ 1 + age | Subject)
oplot <- ggplot(Oxboys, aes(age, height, group = Subject)) + 
  geom_line()

age_grid <- seq(-1, 1, length = 10)
subjects <- unique(Oxboys$Subject)

preds <- expand.grid(age = age_grid, Subject = subjects)
preds$height <- predict(model, preds)


# p.69 �} 
oplot + geom_line(data = preds, colour = "#3366FF", size= 0.4)

Oxboys$fitted <- predict(model)
Oxboys$resid <- with(Oxboys, fitted - height)

# p.70 �} a
oplot %+% Oxboys + aes(y = resid) + geom_smooth(aes(group=1))


model2 <- update(model, height ~ age + I(age ^ 2))
Oxboys$fitted2 <- predict(model2)
Oxboys$resid2 <- with(Oxboys, fitted2 - height)

# p.70 �} b
oplot %+% Oxboys + aes(y = resid2) + geom_smooth(aes(group=1))





############################################################
#               ��5�� �c�[���{�b�N�X Toolbox               #
############################################################

library(effects)

#�@5.3
# p.74
df <- data.frame(
  x = c(3, 1, 5), 
  y = c(2, 4, 6), 
  label = c("a","b","c")
)


# p.74
p <- ggplot(df, aes(x, y, label = label)) + 
  xlab(NULL) + ylab(NULL)

# �}5.1a
p + geom_point() + # opts(title = "geom_point")
     labs(title="geom_point")
     # ���邢��ggtile ("geom_point")���g���܂�

# �}5.1b
p + geom_bar(stat="identity") + #   opts(title = "geom_bar(stat=\"identity\")")
    labs(title="geom_bar(stat=\"identity\")")

# �}5.1c�@
p + geom_line() + # opts(title = "geom_line")
    labs(title="geom_line")

# �}5.1d
p + geom_area() + # opts(title = "geom_area")
    labs(title="geom_area")

# �}5.1e
p + geom_path() + # opts(title = "geom_path")
    labs(title="geom_paths")

# �}5.1f
p + geom_text() + #opts(title = "geom_text")
    labs(title="geom_text")

# �}5.1.g
p + geom_tile() + # opts(title = "geom_tile")
    labs(title="geom_title")

# �}5.1h
p + geom_polygon() + # opts(title = "geom_polygon")
    labs(title="geom_polygon")    
#



# 5.4

# �} 5.2 a
qplot(depth, data=diamonds, geom="histogram")

# �} 5.2 b
qplot(depth, data=diamonds, geom="histogram", xlim=c(55, 70), binwidth=0.1)

# p.76
depth_dist <- ggplot(diamonds, aes(depth)) + xlim(58L, 68L)

# �} 5.3 a
depth_dist + 
  geom_histogram(aes(y = ..density..), binwidth = 0.1) +
  facet_grid(cut ~ .)

# �} 5.3 b
depth_dist + geom_histogram(aes(fill = cut), binwidth = 0.1, 
  position = "fill")

# �} 5.3 c
depth_dist + geom_freqpoly(aes(y = ..density.., colour = cut), 
  binwidth = 0.1) 

# p.78
# �} 5.4 a
qplot(cut, depth, data=diamonds, geom="boxplot")

# �} 5.4 b
qplot(carat, depth, data=diamonds, geom="boxplot", 
  group = round_any(carat, 0.1, floor), xlim = c(0, 3))

# p.78
# p.79
# �} 5.5 a
qplot(class, cty, data=mpg, geom="jitter")

# �} 5.5 b
qplot(class, drv, data=mpg, geom="jitter")


# �} 5.6 a
qplot(depth, data=diamonds, geom="density", xlim = c(54, 70))

# �} 5.6 b
qplot(depth, data = diamonds, geom = "density", xlim = c(54, 70), 
  fill = cut, alpha = I(0.2))

# 5.5
# p.80
df <- data.frame(x = rnorm(2000), y = rnorm(2000))
norm <- ggplot(df, aes(x, y))

# �} 5.7 a
norm + geom_point()

# �} 5.7 b
norm + geom_point(shape = 1)

# �} 5.7 c
norm + geom_point(shape = ".") # �s�N�Z���̃T�C�Y���w��

# p.81
# �} 5.8 a
norm + geom_point(alpha = 1/3, color = "black")

# �} 5.8 b
norm + geom_point(alpha = 1/5, color = "black")

# �} 5.8 c
norm + geom_point(alpha = 1/10, color = "black")
#
   ## norm + geom_point(colour = alpha("black", 1/128))

   ## norm + geom_point(colour = alpha("black", 1/256))

# p.81
td <- ggplot(diamonds, aes(table, depth)) + 
  xlim(50, 70) + ylim(50, 70)

#�@�} 5.9 a
td + geom_point()

#�@�} 5.9 b
td + geom_jitter()

jit <- position_jitter(width = 0.5)

#�@�} 5.9 c
td + geom_jitter(position = jit)

# �} 5.8 d
td + geom_jitter(position = jit, alpha = 1/10, color = "black")

# �} 5.8 e
td + geom_jitter(position = jit, alpha = 1/50, color = "black")

# �} 5.8 f
td + geom_jitter(position = jit, alpha = 1/200, color = "black")

# p.82
d <- ggplot(diamonds, aes(carat, price)) + xlim(1,3) +
  theme(legend.position = "none")
# �} 5.10 a
d + stat_bin2d()

# �} 5.10 b
d + stat_bin2d(bins = 10)

# �} 5.10 c
d + stat_bin2d(binwidth=c(0.02, 200))

# �} 5.10 d
d + stat_binhex()

# �} 5.10 e
d + stat_binhex(bins = 10)

# �} 5.10 f
install.packages("hexbin")

d + stat_binhex(binwidth = c(0.02, 200))

# p.83 
d <- ggplot(diamonds, aes(carat, price)) + xlim(1,3) + 
  theme(legend.position = "none")

# �} 5.11 a
d + geom_point() + geom_density2d()


# �} 5.11 b # ��������і|��Ɍf�ڂ���Ă���}�Ƃ̓f�U�C�������ƂȂ�܂��D
d + stat_density2d(geom = "point", aes(size = ..density..), 
 contour = F) + scale_size_area(c(0.2, 1.5))

# �} 5.11 c# ��������і|��Ɍf�ڂ���Ă���}�Ƃ̓f�U�C�������ƂȂ�܂�
d + stat_density2d(geom = "tile", aes(fill = ..density..), 
  contour = F)

# �} 5.11 d# ��������і|��Ɍf�ڂ���Ă���}�Ƃ̓f�U�C�������ƂȂ�܂�
last_plot() + scale_fill_gradient(limits = c(1e-5,8e-4))


# 5.7
# p.85
# install.packages("maps")
library(maps)
data(us.cities)

big_cities <- subset(us.cities, pop > 500000)
# p.86
# �} 5.12 a
qplot(long, lat, data = big_cities) + borders("state", size = 0.5)

tx_cities <- subset(us.cities, country.etc == "TX")

# �} 5.12 b
ggplot(tx_cities, aes(long, lat)) +
  borders("county", "texas", colour = "grey70") +
  geom_point(alpha = 0.5, color = "black")

# p.86
# library(maps)
states <- map_data("state")
arrests <- USArrests
names(arrests) <- tolower(names(arrests))
arrests$region <- tolower(rownames(USArrests))

choro <- merge(states, arrests, by = "region")

choro <- choro[order(choro$order), ]
# �} 5.13 a
qplot(long, lat, data = choro, group = group, 
  fill = assault, geom = "polygon")

# �} 5.13 b 
qplot(long, lat, data = choro, group = group, 
  fill = assault / murder, geom = "polygon")


ia <- map_data("county", "iowa")
mid_range <- function(x) mean(range(x, na.rm = TRUE))
centres <- ddply(ia, .(subregion), 
  colwise(mid_range, .(lat, long)))

ggplot(ia, aes(long, lat)) + 
  geom_polygon(aes(group = group), 
    fill = NA, colour = "grey60") +
  geom_text(aes(label = subregion), data = centres, 
    size = 2, angle = 45)

# p.87 �}


# 5.8 
# p.88
d <- subset(diamonds, carat < 2.5 & 
  rbinom(nrow(diamonds), 1, 0.2) == 1)
d$lcarat <- log10(d$carat)
d$lprice <- log10(d$price)

detrend <- lm(lprice ~ lcarat, data = d)
d$lprice2 <- resid(detrend)

mod <- lm(lprice2 ~ lcarat * color, data = d)


# p.89
# install.packages("effects")

library(effects)
effectdf <- function(...) {
  suppressWarnings(as.data.frame(effect(...)))
}

color <- effectdf("color", mod)
both1 <- effectdf("lcarat:color", mod)

carat <- effectdf("lcarat", mod, default.levels = 50)
both2 <- effectdf("lcarat:color", mod, default.levels = 3)


qplot(lcarat, lprice, data=d, colour = color)

# �} 5.14 a
qplot(lcarat, lprice, data=d)

qplot(lcarat, lprice2, data=d, colour = color)

# �} 5.14 b
qplot(lcarat, lprice2, data=d)

fplot <- ggplot(mapping = aes(y = fit, ymin = lower, ymax = upper)) +
  ylim(range(both2$lower, both2$upper))

# �} 5.15 a

fplot %+% color + aes(x = color) + geom_point() + geom_errorbar()

# �} 5.15 b
fplot %+% both2 + 
  aes(x = color, colour = lcarat, group = interaction(color, lcarat)) +
  geom_errorbar() + geom_line(aes(group=lcarat)) +
  scale_colour_gradient()

# �} 5.16 a
fplot %+% carat + aes(x = lcarat) + geom_smooth(stat="identity")

ends <- subset(both1, lcarat == max(lcarat))
# �} 5.16 b 
fplot %+% both1 + aes(x = lcarat, colour = color) +
 geom_smooth(stat="identity") + 
 scale_colour_hue() + opts(legend.position = "none") +
 geom_text(aes(label = color, x = lcarat + 0.02), ends)



# 5.9 
# p.91

# m <- ggplot(movies, aes(year, rating))
m <- ggplot(data = movies, aes(x = year, y = rating))
# �} 5.17

# m + stat_summary(fun.y = "median", geom = "line")
m +  layer(geom = "line",  stat = "summary",  fun.y = median)

# m + stat_summary(fun.data = "median_hilow", geom = "smooth")
m +  layer(geom = "smooth",  stat = "summary",  fun.data = median_hilow)

# m + stat_summary(fun.y = "mean", geom = "line")
m +  layer(geom = "line",  stat = "summary",  fun.y = mean)

# m + stat_summary(fun.data = "mean_cl_boot", geom = "smooth")
m +  layer(geom = "smooth",  stat = "summary",  fun.data = mean_cl_boot)


# m2 <- ggplot(movies, aes(round(rating), log10(votes)))
m2 <- ggplot(movies, aes(round(rating), log10(votes)))

# m2 + stat_summary(fun.y = "mean", geom = "point")# + coord_trans(y="log2")
m2 +layer(geom = "point", stat = "summary", fun.y = mean)
    
# m2 + stat_summary(fun.data = "mean_cl_normal", geom = "errorbar")
m2 +  layer(geom = "errorbar", stat = "summary", fun.data = mean_cl_normal)

# m2 + stat_summary(fun.data = "median_hilow", geom = "pointrange")
m2 +  layer(geom = "pointrange", stat = "summary", fun.data = median_hilow)

# m2 + stat_summary(fun.data = "median_hilow", geom = "crossbar")
m2 + layer (geom = "crossbar", stat = "summary", fun.data = median_hilow)


# p.92 �} a
midm <- function(x) mean(x, trim = 0.5)

## m2 + 
##   stat_summary(aes(colour = "trimmed"), fun.y = midm, 
##     geom = "point") +
##   stat_summary(aes(colour = "raw"), fun.y = mean, 
##     geom = "point") +  scale_colour_hue("Mean")

m2 + 
  layer (stat = "summary", mapping = aes(colour = "trimmed"), fun.y = midm, 
    geom = "point") + 
  layer(stat = "summary", mapping = aes(colour = "raw"), fun.y = mean, 
    geom = "point") + scale_color_discrete("Mean")


# p.92 �} b
iqr <- function(x, ...) {
  qs <- quantile(as.numeric(x), c(0.25, 0.75), na.rm = T)
  names(qs) <- c("ymin", "ymax")
  qs
}
m + stat_summary(fun.data = "iqr", geom="ribbon")

m + layer(stat = "summary", fun.data = "iqr", geom="ribbon")


# 5.10

# p.93 �} 

(unemp <- qplot(date, unemploy, data=economics, geom = "line",  xlab = "", ylab = "No. unemployed (1000s)"))

# p.94 �} a 

presidential <- presidential[-(1:3), ]

yrng <- range(economics$unemploy)
xrng <- range(economics$date)

# unemp + geom_vline(aes(xintercept = start), data = presidential)
unemp + geom_vline(aes(xintercept = as.numeric(start)), data = presidential)


# p.94 �} b

unemp + geom_rect(aes(NULL, NULL, xmin = start, xmax = end, 
  fill = party), ymin = yrng[1], ymax = yrng[2], alpha = 0.2,
  data = presidential) + # scale_fill_manual(values = 
  # alpha(c("blue", "red"), 0.2))
 scale_fill_manual(values = c("blue","red"))

# p.94 �} c

last_plot() + geom_text(aes(x = start, y = yrng[1], label = name), 
  data = presidential, size = 3, hjust = 0, vjust = 0)


# p.95 �} a

caption <- paste(strwrap("Unemployment rates in the US have 
  varied a lot over the years", 40), collapse="\n")


unemp + geom_text(aes(x, y, label = caption), 
  data = data.frame(x = xrng[2], y = yrng[2]), 
  hjust = 1, vjust = 1, size = 4)

# p.95 �} b

highest <- subset(economics, unemploy == max(unemploy))

unemp + geom_point(data = highest, 
  size = 3, color = "red", alpha = 0.5)# colour = alpha("red", 0.5))
 

## 5.11

# �} 5.18 a

qplot(percwhite, percbelowpoverty, data = midwest)

# �} 5.18 b

qplot(percwhite, percbelowpoverty, data = midwest, 
  size = poptotal / 1e6) + scale_area("Population\n(millions)", 
  breaks = c(0.5, 1, 2, 4))

# �} 5.18 c

qplot(percwhite, percbelowpoverty, data = midwest, size = area) + 
  scale_area()


# �} 5.19 a

lm_smooth <- geom_smooth(method = lm, size = 1)
qplot(percwhite, percbelowpoverty, data = midwest) + lm_smooth

# �} 5.19 b

qplot(percwhite, percbelowpoverty, data = midwest, 
  weight = popdensity, size = popdensity) + lm_smooth

# �} 5.20 a

qplot(percbelowpoverty, data = midwest, binwidth = 1)

# �} 5.21 b

qplot(percbelowpoverty, data = midwest, weight = poptotal, 
  binwidth = 1) + ylab("population")










############################################################
#       ��Z�� �X�P�[���C���C�}�� scale, axe, legend       #
############################################################

# 6.3
# p.102
plot <- qplot(cty, hwy, data = mpg)
plot

plot + aes(x = drv)

plot + aes(x = drv) + scale_x_discrete()


# p.103
p <- qplot(sleep_total, sleep_cycle, data = msleep, colour = vore)
# �} 6.1 a
p 
# �} 6.1 b
p + scale_colour_hue()

# �} 6.1 c
p + scale_colour_hue("What does\nit eat?", 
   breaks = c("herbi", "carni", "omni", NA), 
   labels = c("plants", "meat", "both", "don't know"))

# �} 6.1 d
p + scale_colour_brewer(palette = "Set1")


# 6.4
p <- qplot(cty, hwy, data = mpg, colour = displ)
# �} 6.2
p
p + scale_x_continuous("City mpg")
p + xlab("City mpg")
p + ylab("Highway mpg")
p + labs(x = "City mpg", y = "Highway", colour = "Displacement")
p + xlab(expression(frac(miles, gallon)))

# p.106
p <- qplot(cyl, wt, data = mtcars)
# �} 6.3 
p

p + scale_x_continuous(breaks = c(5.5, 6.5))

p + scale_x_continuous(limits = c(5.5, 6.5))

p <- qplot(wt, cyl, data = mtcars, colour = cyl)

p

p + scale_colour_gradient(breaks = c(5.5, 6.5))

p + scale_colour_gradient(limits = c(5.5, 6.5))

# p.109
# �} 6.9
qplot(log10(carat), log10(price), data = diamonds)

qplot(carat, price, data = diamonds) + 
  scale_x_log10() + scale_y_log10()

# p.110
# �} 6.10 
plot <- qplot(date, psavert, data = economics, geom = "line") + 
  ylab("Personal savings rate") +
  geom_hline(xintercept = 0, colour = "grey50")

plot

plot + scale_x_date(breaks = "10 years")# scale_x_date(major = "10 years")

library(scales)
plot + scale_x_date(
  limits = as.Date(c("2004-01-01", "2005-01-01")),
  labels = date_format("%Y-%m-%d")# format = "%Y-%m-%d"
)



# p.114
f2d <- with(faithful, MASS::kde2d(eruptions, waiting, 
  h = c(1, 10), n = 50))
df <- with(f2d, cbind(expand.grid(x, y), as.vector(z)))
names(df) <- c("eruptions", "waiting", "density")
erupt <- ggplot(df, aes(waiting, eruptions, fill = density)) +
  geom_tile() +
  scale_x_continuous(expand = c(0, 0)) + 
  scale_y_continuous(expand = c(0, 0))

# �} 6.7
erupt + scale_fill_gradient(limits = c(0, 0.04))

erupt + scale_fill_gradient(limits = c(0, 0.04), 
  low = "white", high = "black")

erupt + scale_fill_gradient2(limits = c(-0.04, 0.04), 
  midpoint = mean(df$density)) 

# p.115
# install.packages ("vcd")
library(vcd)
fill_gradn <- function(pal) {
  scale_fill_gradientn(colours = pal(7), limits = c(0, 0.04))
}

# �} 6.8
install.packages("colorspace")
library (colorspace)
erupt + fill_gradn(rainbow_hcl)

erupt + fill_gradn(diverge_hcl)

erupt + fill_gradn(heat_hcl)

# p.116
point <- qplot(brainwt, bodywt, data = msleep, log = "xy", 
  colour = vore)

area <- qplot(log10(brainwt), data = msleep, fill = vore, 
  binwidth = 1)

# �} 6.9
point + scale_colour_brewer(palette = "Set1")

point + scale_colour_brewer(palette = "Set2")

point + scale_colour_brewer(palette = "Pastel1")

area + scale_fill_brewer(palette = "Set1")

area + scale_fill_brewer(palette = "Set2")

area + scale_fill_brewer(palette = "Pastel1")


# p.117
plot <- qplot(brainwt, bodywt, data = msleep, log = "xy")

# �} 6.10 a
plot + aes(colour = vore) + 
  scale_colour_manual(values = c("red", "orange", "yellow",   "green", "blue"))

colours <- c(carni = "red", "NA" = "orange", insecti = "yellow", 
  herbi = "green", omni = "blue")
# �} 6.10 b
plot + aes(colour = vore) + scale_colour_manual(values = colours)

plot + aes(shape = vore) + 
  scale_shape_manual(values = c(1, 2, 6, 0, 23))

# p.118 �} 
huron <- data.frame(year = 1875:1972, level = LakeHuron)
ggplot(huron, aes(year)) +
  geom_line(aes(y = level - 5), colour = "blue") + 
  geom_line(aes(y = level + 5), colour = "red")


# p.119 �} a
ggplot(huron, aes(year)) +
  geom_line(aes(y = level - 5, colour = "below")) + 
  geom_line(aes(y = level + 5, colour = "above"))

# p.119 �} b
ggplot(huron, aes(year)) +
  geom_line(aes(y = level - 5, colour = "below")) + 
  geom_line(aes(y = level + 5, colour = "above")) + 
  scale_colour_manual("Direction", values = 
    c("below" = "blue", "above" = "red"))


# p.120
# �} 6.11
# library (ggplot2)
x <- colors()
luv <- as.data.frame(convertColor(t(col2rgb(x)), "sRGB", "Luv"))
# �`��Ɏ��Ԃ������邱�Ƃ�����̂Œ��ӂ��Ă�������

qplot(u, v, data = luv, colour = x, size = I(3)) + scale_alpha_identity() + coord_equal()
# qplot(u, v, data = luv)

# p.121
p <- ggplot(diamonds[1:100, ], aes(price, carat, colour = cut)) # +  # opts(keep = "legend_box")
    
# �} 6.13
p + geom_point()

p + geom_line()

p + geom_point() + geom_line()

p + geom_bar(binwidth = 100) + aes(fill = cut, y = ..count..)

p <- ggplot(diamonds[1:100, ], aes(price, carat)) +  
  geom_point() # +   opts(keep = "legend_box")

# p.122
# �} 6.14
p + aes(colour = cut)

p + aes(shape = cut)

p + aes(shape = cut, colour = cut)




############################################################
#               �� 7 �� �ʒu�ݒ�    Positioning             #
############################################################

library(ggplot2)

# 7.2
# p.126 
mpg2 <- subset(mpg, cyl != 5 & drv %in% c("4", "f"))
head(mpg2)

# p.127 �} a
qplot(cty, hwy, data = mpg2) # + facet_grid(. ~ cyl)


# p.127 �} b 
qplot(cty, hwy, data = mpg2) + facet_grid(. ~ cyl)

# p.128 �} a

qplot(cty, data = mpg2, geom="histogram", binwidth = 2) +
  facet_grid(cyl ~ .)

# p.128 �} b

qplot(cty, hwy, data = mpg2) + facet_grid(drv ~ cyl)

# 
p <- qplot(displ, hwy, data = mpg2) +
  geom_smooth(method = "lm", se = F)

# �} 7.2 a
p + facet_grid(cyl ~ drv)

# �} 7.2 b
p + facet_grid(cyl ~ drv, margins = T)

qplot(displ, hwy, data = mpg2) + 
  geom_smooth(aes(colour = drv), method = "lm", se = F) + 
  facet_grid(cyl ~ drv, margins = T) 

# p.131
# �} 7.3
library(reshape)

movies$decade <- round_any(movies$year, 10, floor)

qplot(rating, ..density.., data=subset(movies, decade > 1890),
  geom="histogram", binwidth = 0.5) + 
  facet_wrap(~ decade, ncol = 6)

p <- qplot(cty, hwy, data = mpg)

# �} 7.4 a
p + facet_wrap(~ cyl)

# �} 7.4 b
p + facet_wrap(~ cyl, scales = "free")

# �} 7.5 
em <- melt(economics, id = "date")
qplot(date, value, data = em, geom = "line", group = variable) + 
  facet_grid(variable ~ ., scale = "free_y")

# �} p.133
mpg3 <- within(mpg2, {
  model <- reorder(model, cty)
  manufacturer <- reorder(manufacturer, -cty)
})
models <- qplot(cty, model, data = mpg3)

# �} 7.6 a
models

# �} 7.6 b
## models + facet_grid(manufacturer ~ ., scales = "free", 
##   space = "free") +  opts(strip.text.y = theme_text())
models + facet_grid(manufacturer ~ ., scales = "free", 
  space = "free") +  theme (strip.text.y = element_text())

# p.134
xmaj <- c(0.3, 0.5, 1,3, 5)
xmin <- as.vector(outer(1:10, 10^c(-1, 0)))
ymaj <- c(500, 1000, 5000, 10000)
ymin <- as.vector(outer(1:10, 10^c(2,3,4)))

## dplot <- ggplot(subset(diamonds, color %in% c("D","E","G","J")), 
##   aes(carat, price, colour = color)) + 
##   scale_x_log10(breaks = xmaj, labels = xmaj, minor = xmin) + 
##   scale_y_log10(breaks = ymaj, labels = ymaj, minor = ymin) + 
##   scale_colour_hue(limits = levels(diamonds$color)) + 
##   opts(legend.position = "none")
dplot <- ggplot(subset(diamonds, color %in% c("D","E","G","J")), 
  aes(carat, price, colour = color)) + 
  scale_x_log10(breaks = xmaj, labels = xmaj, minor = xmin) + 
  scale_y_log10(breaks = ymaj, labels = ymaj, minor = ymin) + 
  scale_colour_hue(limits = levels(diamonds$color)) + 
  theme (legend.position = "none")

# �} 7.7 a
dplot + geom_point()

# �} 7.7 b 
dplot + geom_point() + facet_grid(. ~ color)

# �} 7.7 c 
dplot + geom_smooth(method = lm, se = F, fullrange = T)

# �} 7.7 d 
dplot + geom_smooth(method = lm, se = F, fullrange = T) + 
  facet_grid(. ~ color)

# �} 7.8 a
qplot(color, data=diamonds, geom = "bar", fill = cut, 
  position="dodge")

# �} 7.8 b
## qplot(cut, data = diamonds, geom = "bar", fill = cut) + 
##   facet_grid(. ~ color) + 
##   opts(axis.text.x = theme_text(angle = 90, hjust = 1, size = 8, 
##    colour = "grey50"))
qplot(cut, data = diamonds, geom = "bar", fill = cut) + 
  facet_grid(. ~ color) + 
  theme (axis.text.x = element_text(angle = 90, hjust = 1, size = 8,    colour = "grey50"))

# p.137

mpg4 <- subset(mpg, manufacturer %in% 
  c("audi", "volkswagen", "jeep"))
mpg4$manufacturer <- as.character(mpg4$manufacturer)
mpg4$model <- as.character(mpg4$model)

## base <- ggplot(mpg4, aes(fill = model)) + 
##   geom_bar(position = "dodge") + 
##   opts(legend.position = "none")
base <- ggplot(mpg4, aes(fill = model)) + 
  geom_bar(position = "dodge") + 
  theme (legend.position = "none")

# �} 7.9 a
base + aes(x = model) + 
  facet_grid(. ~ manufacturer)

# �} 7.9 b  
last_plot() +  
  facet_grid(. ~ manufacturer, scales = "free_x", space = "free")

# �} 7.9 c
base + aes(x = manufacturer)

# p.139
mpg2$disp_ww <- cut_interval(mpg2$displ, length = 1)
mpg2$disp_wn <- cut_interval(mpg2$displ, n = 6)
mpg2$disp_nn <- cut_number(mpg2$displ, n = 6)

plot <- qplot(cty, hwy, data = mpg2) + labs(x = NULL, y = NULL)

# �} 7.10 a
plot + facet_wrap(~ disp_ww, nrow = 1)

# �} 7.10 b
plot + facet_wrap(~ disp_wn, nrow = 1)

# �} 7.10 c
plot + facet_wrap(~ disp_nn, nrow = 1)

# 7.3

rect <- data.frame(x = 50, y = 50)
line <- data.frame(x = c(1, 200), y = c(100, 1))
base <- ggplot(mapping = aes(x, y)) + 
  geom_tile(data = rect, aes(width = 50, height = 50)) + 
  geom_line(data = line)

# �} 7.11
base

base + coord_polar("x")

base + coord_polar("y")

base + coord_flip()

base + coord_trans(y = "log10")

base + coord_equal()

# p.142
r_grid <- seq(0, 1, length = 15)
theta_grid <- seq(0, 3 / 2 * pi, length = 15)
extents <- data.frame(r = range(r_grid), theta = range(theta_grid))

## base <- ggplot(extents, aes(r, theta)) + opts(aspect.ratio = 1) +
##   scale_y_continuous(expression(theta))
base <- ggplot(extents, aes(r, theta)) + theme(aspect.ratio = 1) +
  scale_y_continuous(expression(theta))
# �} 7.12

base + geom_point(colour = "red", size = 4) + geom_line()

pts <- data.frame(r = r_grid, theta = theta_grid)

base + geom_line() + geom_point(data = pts)

base + geom_point(data = pts)

xlab <- scale_x_continuous(expression(x == r * sin(theta)))
ylab <- scale_y_continuous(expression(x == r * cos(theta)))
polar <- base %+% pts + aes(x = r * sin(theta), y = r * cos(theta)) + 
  xlab + ylab

# �} 7.12 c
polar + geom_point()

polar + geom_point() + geom_path()

polar + geom_point(data=extents, colour = "red", size = 4) + geom_path() 

# p.143
# �} 7.13
(p <- qplot(disp, wt, data=mtcars) + geom_smooth())

p + scale_x_continuous(limits = c(325, 500))

p + coord_cartesian(xlim = c(325, 500))


# �} 7.14
## (d <- ggplot(diamonds, aes(carat, price)) + 
##   stat_bin2d(bins = 25, colour="grey70") + 
##   opts(legend.position = "none"))
(d <- ggplot(diamonds, aes(carat, price)) + 
  stat_bin2d(bins = 25, colour="grey70") + 
  theme(legend.position = "none"))


d + scale_x_continuous(limits = c(0, 2))

d + coord_cartesian(xlim = c(0, 2))

# �} 7.15
qplot(displ, cty, data = mpg) + geom_smooth()

qplot(cty, displ, data = mpg) + geom_smooth()

qplot(cty, displ, data = mpg) + geom_smooth() + coord_flip()

# p.145
# �} 7.16
qplot(carat, price, data = diamonds, log = "xy") + 
  geom_smooth(method = "lm")


last_plot()  + #  coord_trans(x = "pow10", y = "pow10")
 coord_trans(x = exp_trans (10), y = exp_trans (10))


# p.146
# �} 7.17
(pie <- ggplot(mtcars, aes(x = factor(1), fill = factor(cyl))) +
  geom_bar(width = 1))

pie + coord_polar(theta = "y")

pie + coord_polar()




##################################################################
#�� 8 �� �o�ł̂��߂̃O���t Polishing Your Plots For Publications#
##################################################################

library( ggplot2 )

# 8.1
# �} 8.1 
qplot(rating, data = movies, binwidth = 1)
last_plot() + theme_bw()


# p.151
hgram <- qplot(rating, data = movies, binwidth = 1)
hgram

# p.152
previous_theme <- theme_set(theme_bw())
hgram

#  p.152
hgram + previous_theme

# p.152 
theme_set(previous_theme)

# p.154
#hgramt <- hgram +   opts(title = "This is a histogram")
# hgramt <- hgram +   labs(title = "This is a histogram")
hgramt <- hgram +   ggtitle("This is a histogram")
#      labs (title = "This is a histogram")

# �} 8.2
hgramt  

# hgramt +  opts(plot.title = theme_text(size = 20))
hgramt +  theme (title = element_text(size = 20))

# hgramt + opts(plot.title = theme_text(size = 20,   colour = "red"))
hgramt + theme (title = element_text(color = "red"))

# hgramt + opts(plot.title = theme_text(size = 20,   hjust = 0))
hgramt +  theme (title = element_text(size = 20, hjust = 0))

# hgramt + opts(plot.title = theme_text(size = 20,   face = "bold"))
hgramt +  theme (title = element_text(size = 20, face = "bold" ))

# hgramt + opts(plot.title = theme_text(size = 20,   angle = 180))
hgramt +  theme (title = element_text(size = 20, angle = 180 ))

# p.155
# �} 8.3
# hgram + opts(panel.grid.major = theme_line(colour = "red"))
hgram +  theme (panel.grid.major = element_line(colour = "red"))


# hgram + opts(panel.grid.major = theme_line(size = 2))
hgram +  theme (panel.grid.major = element_line(size = 2))


# hgram + opts(panel.grid.major = theme_line(linetype = "dotted"))
hgram +  theme (panel.grid.major = element_line(linetype = "dotted"))

# hgram + opts(panel.grid.major = theme_line(linetype = 0))
hgram +  theme (panel.grid.major = element_line(linetype = 0))

# hgram + opts(axis.line = theme_segment())
hgram +  theme (axis.line = element_line())

# hgram + opts(axis.line = theme_segment(colour = "red"))
hgram +  theme (axis.line = element_line(colour = "red"))

# hgram + opts(axis.line = theme_segment(size = 0.5, linetype = "dashed"))
hgram +  theme (axis.line = element_line(size = 0.5, linetype = "dashed"))

# p.155
# �} 8.4
# hgram + opts(plot.background = theme_rect(fill = "grey80",   colour = NA))
hgram +  theme (plot.background = element_rect(fill = "grey80",   colour = NA))
    
# hgram + opts(plot.background = theme_rect(size = 2))
hgram +  theme (plot.background = element_rect(size = 2))

# hgram + opts(plot.background = theme_rect(colour = "red"))
hgram +  theme (plot.background = element_rect(colour = "red"))

#hgram + opts(panel.background = theme_rect())
hgram +  theme (plot.background = element_rect())
                    
# hgram + opts(panel.background = theme_rect(colour = NA))
hgram +  theme (plot.background = element_rect(colour = NA))

#hgram + opts(panel.background =  theme_rect(linetype = "dotted"))
hgram +  theme (plot.background = element_rect(linetype = "dotted"))
# p.156
# �} 8.5
hgram

# last_plot() + opts(panel.grid.minor = theme_blank())
last_plot() + theme (panel.grid.minor = element_blank())
    
# last_plot() + opts(panel.grid.major = theme_blank())
last_plot() + theme (panel.grid.major = element_blank())

# last_plot() + opts(panel.background = theme_blank())
last_plot() + theme (panel.background = element_blank())

# last_plot() + opts(panel.background = theme_blank(), colour = NA, fill = NA)

#last_plot() + opts(axis.title.x = theme_blank(),  axis.title.y = theme_blank())
last_plot() + theme ( axis.title.x = element_blank(),  axis.title.y = element_blank())

# last_plot() + opts(axis.title.x = theme_blank(),  axis.title.y = theme_blank(), colour = NA, fill = NA )
# last_plot() + theme ( axis.title.x = element_blank(),  axis.title.y = element_blank(), colour = NA, fill = NA )

# last_plot() + opts(axis.line = theme_segment())
last_plot() + theme(axis.line = element_line())

# p.157

## old_theme <- theme_update(
##   plot.background = theme_rect(fill = "#3366FF"),
##   panel.background = theme_rect(fill = "#003DF5"),
##   axis.text.x = theme_text(colour = "#CCFF33"),
##   axis.text.y = theme_text(colour = "#CCFF33", hjust = 1),
##   axis.title.x = theme_text(colour = "#CCFF33", face = "bold"),
##   axis.title.y = theme_text(colour = "#CCFF33", face = "bold", 
##    angle = 90)
## )
old_theme <- theme_update(
  plot.background = element_rect(fill = "#3366FF"),
  panel.background = element_rect(fill = "#003DF5"),
  axis.text.x = element_text(colour = "#CCFF33"),
  axis.text.y = element_text(colour = "#CCFF33", hjust = 1),
  axis.title.x = element_text(colour = "#CCFF33", face = "bold"),
  axis.title.y = element_text(colour = "#CCFF33", face = "bold", 
   angle = 90)
)


# �} 8.6
qplot(cut, data = diamonds, geom="bar")

qplot(cty, hwy, data = mpg)

theme_set(old_theme)


# 8.2
# p.158
# set_default_scale("colour", "discrete", "grey")
scale_colour_discrete ("colour", "discrete", "grey")

# set_default_scale("fill", "discrete", "grey")
scale_colour_discrete ("fill", "discrete", "grey")

# set_default_scale("colour", "continuous", "gradient",    low = "white", high = "black")
scale_colour_gradient(low ="white", high ="black")

# set_default_scale("fill", "continuous", "gradient",    low = "white", high = "black")


update_geom_defaults("point", aes(colour = "darkblue"))

qplot(mpg, wt, data=mtcars)

update_stat_defaults("bin", aes(y = ..density..))

qplot(rating, data = movies, geom = "histogram", binwidth = 1)

# 8.3
# p.161
qplot(mpg, wt, data = mtcars)
ggsave(file = "output.pdf")

pdf(file = "output.pdf", width = 6, height = 6)

qplot(mpg, wt, data = mtcars)
qplot(wt, mpg, data = mtcars)
  dev.off()

# 8.4
#  �} 8.8
(a <- qplot(date, unemploy, data = economics, geom = "line"))

(b <- qplot(uempmed, unemploy, data = economics) +   geom_smooth(se = F))

(c <- qplot(uempmed, unemploy, data = economics, geom="path"))

# p.163
vp1 <- viewport(width = 1, height = 1, x = 0.5, y = 0.5)
# vp1 <- viewport()

vp2 <- viewport(width = 0.5, height = 0.5, x = 0.5, y = 0.5)
# vp2 <- viewport(width = 0.5, height = 0.5)

vp3 <- viewport(width = unit(2, "cm"), height = unit(3, "cm"))

print (vp1)
print (vp3)
#

# p.164
# vp4 <- viewport(x = 1, y = 1, just = c("top", "right"))

vp4 <- viewport(x = 1, y = 1, just = c("right" , "top"))

# vp5 <- viewport(x = 0, y = 0, just = c("bottom", "right"))
vp5 <- viewport(x = 0, y = 0, just = c("right", "bottom"))


# �} 8.9 a
pdf("polishing-subplot-1.pdf", width = 4, height = 4)

subvp <- viewport(width = 0.4, height = 0.4, x = 0.75, y = 0.35)
b
print(c, vp = subvp)

  dev.off()

## csmall <- c + 
##   theme_gray(9) + 
##   labs(x = NULL, y = NULL) + 
##   opts(plot.margin = unit(rep(0, 4), "lines"))
library(grid)

csmall <- c + 
  theme_gray(9) + 
  labs(x = NULL, y = NULL) + 
  theme (plot.margin = unit(rep(0, 4), "lines"))


# �} 8.9 b
pdf("polishing-subplot-2.pdf", width = 4, height = 4)
b
print(csmall, vp = subvp)
  dev.off()

# p.165
pdf("polishing-layout.pdf", width = 8, height = 6)
grid.newpage()
pushViewport(viewport(layout = grid.layout(2, 2)))

vplayout <- function(x, y) 
  viewport(layout.pos.row = x, layout.pos.col = y)

# �} 8.10
print(a, vp = vplayout(1, 1:2))
print(b, vp = vplayout(2, 1))
print(c, vp = vplayout(2, 2))
dev.off()





############################################################
#            ��9�� �f�[�^���� Manipulating data            #
############################################################

library(ggplot2)

options(digits = 2, width = 60)

# 9.1 
# p.168

# �ȉ��C���̂܂܎��s����ƃR���\�[�������ߐs������邱�Ƃ�����܂��D���ӂ��Ă��������D

library(plyr)

ddply(diamonds, .(color), subset, carat == min(carat))


ddply(diamonds, .(color), subset, order(carat) <= 2)

# p.169
ddply(diamonds, .(color), subset, carat > 
  quantile(carat, 0.99))


ddply(diamonds, .(color), subset, price > mean(price))


ddply(diamonds, .(color), transform, price = scale(price))


ddply(diamonds, .(color), transform,  price = price - mean(price))

nmissing <- function(x) sum(is.na(x))
nmissing(msleep$name)
nmissing(msleep$brainwt)

nmissing_df <- colwise(nmissing)
nmissing_df(msleep)

# p.170
colwise(nmissing)(msleep)

msleep2 <- msleep[, -6] 
numcolwise(median)(msleep2, na.rm = T)
numcolwise(quantile)(msleep2, na.rm = T)

numcolwise(quantile)(msleep2, probs = c(0.25, 0.75), 
  na.rm = T)

ddply(msleep2, .(vore), numcolwise(median), na.rm = T)

# p.171
ddply(msleep2, .(vore), numcolwise(mean), na.rm = T)

my_summary <- function(df) {
  with(df, data.frame(
    pc_cor = cor(price, carat, method = "spearman"),
    lpc_cor = cor(log(price), log(carat))
  ))
}

ddply(diamonds, .(cut), my_summary)

ddply(diamonds, .(color), my_summary)


# 9.1.1
# p.172
# �} 9.1
qplot(carat, price, data = diamonds, geom = "smooth",  colour = color)

dense <- subset(diamonds, carat < 2)

qplot(carat, price, data = dense, geom = "smooth",  colour = color,  fullrange = TRUE)

# p.173
library(mgcv)

smooth <- function(df) {
  mod <- gam(price ~ s(carat, bs = "cs"), data = df)
  grid <- data.frame(carat = seq(0.2, 2, length = 50))
  pred <- predict(mod, grid, se = T)  
  grid$price <- pred$fit
  grid$se <- pred$se.fit
  grid
}

smoothes <- ddply(dense, .(color), smooth )

# �} 9.2
qplot(carat, price, data = smoothes, colour = color,  geom = "line")

qplot(carat, price, data = smoothes, colour = color, 
  geom = "smooth", ymax = price + 2 * se, ymin = price - 2 * se)

# p.174
mod <- gam(price ~ s(carat, bs = "cs") + color, data = dense)

grid <- with(diamonds, expand.grid(
  carat = seq(0.2, 2, length = 50),
  color = levels(color)
))
grid$pred <- predict(mod, grid)
# p.174 �}

qplot(carat, pred, data = grid, colour = color, geom = "line")


# 9.2
# p.176
# �} 9.3
qplot(date, uempmed, data = economics, geom = "line")

qplot(date, unemploy, data = economics, geom = "line")

qplot(unemploy, uempmed, data = economics) + geom_smooth()


# p.177
# �} 9.4 a
ggplot(economics, aes(date)) + 
  geom_line(aes(y = unemploy, colour = "unemploy")) + 
  geom_line(aes(y = uempmed, colour = "uempmed")) + 
  scale_colour_hue("variable")

library(reshape)

emp <- melt(economics, id = "date", measure = c("unemploy", "uempmed"))
# �} 9.4 b

qplot(date, value, data = emp, geom = "line", colour = variable)

# p.178

range01 <- function(x) {
  rng <- range(x, na.rm = TRUE)
  (x - rng[1]) / diff(rng)
}
emp2 <- ddply(emp, .(variable), transform, value = range01(value))

# �} 9.5
qplot(date, value, data = emp2, geom = "line", 
  colour = variable, linetype = variable)


qplot(date, value, data = emp, geom = "line") + 
  facet_grid(variable ~ ., scales = "free_y")


# p.179
popular <- subset(movies, votes > 1e4)
ratings <- popular[, 7:16]
ratings$.row <- rownames(ratings)
molten <- melt(ratings, id = ".row")
# head(molten)
# 
pcp <- ggplot(molten, aes(variable, value, group = .row))

# p.180
# �} 9.6
pcp + geom_line()

# pcp + geom_line(colour = alpha("black", 1 / 20))
pcp + geom_line(colour = "black" , alpha = 1 / 20)

jit <- position_jitter(width = 0.25, height = 2.5)
pcp + geom_line(position = jit)

# pcp + geom_line(colour = alpha("black", 1 / 20), position = jit)
pcp + geom_line(colour = "black", alpha = 1 / 20, position = jit)

cl <- kmeans(ratings[1:10], 6)
ratings$cluster <- reorder(factor(cl$cluster), popular$rating)
levels(ratings$cluster) <- seq_along(levels(ratings$cluster))
molten <- melt(ratings, id = c(".row", "cluster"))

# 
pcp_cl <- ggplot(molten, 
  aes(variable, value, group = .row, colour = cluster))

# �} 9.7
pcp_cl + geom_line(position = jit, alpha = 1/5)

pcp_cl + stat_summary(aes(group = cluster), fun.y = mean, 
  geom = "line")

# �} 9.8 
## pcp_cl + geom_line(position = jit, colour = alpha("black", 1/5)) +
##   facet_wrap(~ cluster)
pcp_cl + geom_line(position = jit, colour = "black", alpha = 1/5) +   facet_wrap(~ cluster)


# 9.3
# p.184 
qplot(displ, cty, data = mpg) + geom_smooth(method = "lm")
mpgmod <- lm(cty ~ displ, data = mpg)
fortify(mpgmod)


# p.185
mod <- lm(cty ~ displ, data = mpg)
basic <- ggplot(mod, aes(.fitted, .resid)) +
  geom_hline(yintercept = 0, colour = "grey50", size = 0.5) + 
  geom_point() + 
  geom_smooth(size = 0.5, se = F)

# �} 9.11
basic

basic + aes(y = .stdresid)

basic + aes(size = .cooksd) + scale_area("Cook's distance")

# �} 9.2
full <- basic %+% fortify(mod, mpg)
full + aes(colour = factor(cyl))

full + aes(displ, colour = factor(cyl))


# p.186
fortify.Image <- function(model, data, ...) {
  #  colours <- channel(model, "x11")[ , , ]
  colours <- channel(model, "x11")[,]
  colours <- colours[, rev(seq_len(ncol(colours)))]
  melt(colours, c("x", "y"))
}


## fortify.Image <- function(model, data, ...) {
##   colours <- channel(model, "gray")[,,]
##   colours <- colours[, rev(seq_len(ncol(colours)))]
##   melt(colours, c("x", "y"))
## }


## Bioconductor �̈ꊇ�C���X�g�[��
## source("http://bioconductor.org/biocLite.R")
## biocLite()
## biocLite("EBImage")

## �u�p�b�P�[�W�v���u�_�E�����[�h�T�C�g�̑I���v
## �uBioC annotation�v
## �u�p�b�P�[�W�v���u�p�b�P�[�W�̃C���X�g�[���v


library(EBImage) 
#
img <- readImage("http://had.co.nz/me.jpg")
qplot(x, y, data = img, fill = value, geom="tile") + 
  scale_fill_identity() + coord_equal()








############################################################
#                �� 10 �� �����̎�Ԃ̌y��                  #
#                   Reducing duplication                   #
############################################################

library(ggplot2)
options(digits = 2)

# 10.2
# p.190
# �} 10.1
qplot(x, y, data = diamonds, na.rm = TRUE)

last_plot() + xlim(3, 11) + ylim(3, 11)

last_plot() + xlim(4, 10) + ylim(4, 10)

last_plot() + xlim(4, 5) + ylim(4, 5)

last_plot() + xlim(4, 4.5) + ylim(4, 4.5)

last_plot() + geom_abline(colour = "red")

qplot(x, y, data = diamonds, na.rm = T) + 
  geom_abline(colour = "red") +
  xlim(4, 4.5) + ylim(4, 4.5)

# 10.3
# p.191

gradient_rb <- scale_colour_gradient(low = "red", high = "blue")

# �} 10.2
qplot(cty, hwy, data = mpg, colour = displ) + gradient_rb

qplot(bodywt, brainwt, data = msleep, colour = awake, log="xy") +
  gradient_rb

# 
xquiet <- scale_x_continuous("", breaks = NA)
yquiet <- scale_y_continuous("", breaks = NA)
quiet <- c(xquiet, yquiet)

# p.192
# �} 10.3
# qplot(mpg, wt, data = mtcars) # + quiet
qplot(mpg, wt, data = mtcars)  + scale_x_continuous("", breaks = NA) + scale_y_continuous("", breaks = NA)

# qplot(displ, cty, data = mpg) + quiet
qplot(displ, cty, data = mpg) + scale_x_continuous("", breaks = NA) + scale_y_continuous("", breaks = NA)

# 
geom_lm <- function(formula = y ~ x) {
  geom_smooth(formula = formula, se = FALSE, method = "lm")
}

# �} 10.4
qplot(mpg, wt, data = mtcars) + geom_lm()

library(splines)
qplot(mpg, wt, data = mtcars) + geom_lm(y ~ ns(x, 3))


# 10.4
# p.193
pcp_data <- function(df) {
  numeric <- laply(df, is.numeric)
  df[numeric] <- colwise(range01)(df[numeric])
  df$.row <- rownames(df)
  dfm <- melt(df, id = c(".row", names(df)[!numeric]))
  class(dfm) <- c("pcp", class(dfm))
  dfm
}

pcp <- function(df, ...) {
  df <- pcp_data(df)
  ggplot(df, aes(variable, value)) + geom_line(aes(group = .row))
}

pcp(mpg)

pcp(mpg) + aes(colour = drv)

