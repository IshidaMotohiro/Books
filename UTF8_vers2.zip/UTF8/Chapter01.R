
setwd ("C:/Users/ishida/Dropbox/hitsuji/hitsuji_data/SJIS")# この行、あとで消す

##　本書のサポートサイトからダウンロードしたファイル　hituji.zip　を解凍すると
SJISとUTF8の２種類のフォルダがあります。WindowsユーザーはSJISを、
またMacユーザーはUTF8フォルダ中にあるファイル及びフォルダ群を利用してください。

それぞれのフォルダにはdataというフォルダがあります。
これをWindowsのホームフォルダ

C:/Users/ユーザー名/Documents　

Macユーザーはホームフォルダ

/Users/ユーザ名

にコピーしたとします。

# 第一章　スクリプト
##　森鴎外と夏目漱石のテキストをクラスター分析で分ける
以下の操作を行うためにはサポートサイトからダウロードしたdata
ファルダ、およびRMeCabパッケージのインストールが必要です。
詳細は本書第３章を参照してください。

#　RMeCabパッケージのロード
library (RMeCab)

# 作業スペースの移動（第２章参照）
setwd ("C:/Users/ユーザー名/Documents/data")


#　初回実行時、やや時間がかかります
#　バイグラムの抽出

res <- docNgram("writers", type = 0) # writers はフォルダ名
#　グラフの作成。テキスト本文とは異なり、鴎外、漱石、それぞれの作品名をローマ字略記で表しています 

　　　　#　やや高度:グラフのラベル変更方法の一例
　　　　# グラフの列ラベルを変更する方法
　　　　  colnames (res) <- c(paste("鴎外",LETTERS[1:4]),paste("漱石", LETTERS[5:8]))
　　　　#　ここでpaste()関数は、文字列を結合する関数
      paste ("LABEL", 1:10, sep = ":")

plot( hclust(dist( t(res)),"ward" ))
# 区切りの水平線を引く。ltyは線の種類を番号で表す。lwdは線の太さ
abline (h = 500, lty = 2,  lwd = 2)

##　2. 計量言語研究

# 麻生元総理の所信表明演説から頻度表を作成

aso <- RMeCabFreq ("PM/Aso.txt")

# X軸、Y軸ともに対数をとってグラフにする

plot (log (1:nrow (aso)),  log (sort (aso $Freq,decreasing =TRUE)), xlab = "順位の対数", ylab = "単語の対数", main = "麻生元総理の演説")

#　線形回帰分析で直線を推定し

aso.lm <- lm ( log (sort (aso $Freq,decreasing =TRUE)) ~ log (1:nrow (aso)))

#　プロットに追加する

abline(aso.lm)


##　7. 日本語・日本文学研究におけるテキストマイニンク?

res <- docNgram("writers", type = 0) # writers はフォルダ名

#　文字と読点のバイグラム

res2 <- res[ rownames(res) %in% c("[と-、]", "[て-、]", "[は-、]", "[が-、]", "[で-、]",  "[に-、]",  "[ら-、]",  "[も-、]" ) ,  ]

## 主成分分析

res2.pc <- princomp(t(res2))

#　作品名はローマ字略記で表示
biplot(res2.pc)




