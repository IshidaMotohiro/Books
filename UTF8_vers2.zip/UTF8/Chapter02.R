#　第2章　Rと基本統計量

getwd() # 作業フォルダの確認

#setwd("D:/data") # 作業フォルダの変更

#　本書では　C:/Users/ユーザー名/Documents　を作業スペースとする

# 作業スペースの移動（第２章参照）
setwd ("C:/Users/ユーザー名/Documents/data")


1 + 2

x <- 1 # 数値の代入
y <- "1" #文字列の代入
x + 1

y + 1


x <- c(1, 2, 3) # ベクトルの代入
x[c(1, 3)] # xの1番目と3番目の要素を抽出
x + 1 # xの各要素に1を足す
y <- 1:10 # 1～10の数値をyに代入
y[3:5] # yの3～5番目の要素を抽出
y * 3

Z <- c(44, 48, 66, 51, 51, 67, 55, 37, 43, 46) # ベクトルの代入
Z #代入したベクトルの確認

mean(Z) # 平均
sd(Z) # 標準偏差

dat <- read.csv("myData.csv") # csvファイルの読み込み
head (dat) # データの冒頭6行の表示

nrow(dat); ncol(dat) # 行数と列数（セミコロン;で複数の命令を結合）
dat [2:5, 2:3] # 2-5行の2-3列を表示


sum(dat$Freq) # 頻度の合計


# ファイルの読み込み
dat3 <- read.csv("data2.csv", skip = 2, row.names = 1, 
              fileEncoding = "CP932")
dat3 # データの確認
rownames(dat3)　# データの列名の表示

# タブ形式のファイルの読み込み
tabData <- read.delim("data3.txt")


(x <- matrix(1:9, ncol = 3)) # 3行3列の行列
x[1:2, 2:3] # そこから1-2行目と2-3列目を抽出

colSums(x) # 列ごとの合計
rowSums(x) # 行ごとの合計


## 5.	基本統計量

##再現可能なデータを擬似的に生成する準備

set.seed (12)　#　乱数の種を設定します。

##　平均が50、標準偏差が3となる数値を30個生成する

A <- round (rnorm(30, me = 50, sd = 3), 0)

##　　平均が50、標準偏差が10となる数値を30個生成する
B <- round (rnorm(30, me = 50, sd = 10),0)

mean(A); mean(B) # 平均


##　ヒストグラムの作成

par (mfrow = c(1,2)) # 画面を1行2列に分解
hist(A, breaks = seq (20,80, 5))#横軸を２０から８０まで５刻みとする
hist(B, breaks = seq (20,80, 5))

dev.off()#グラフを閉じる

var(A); sd(A) # 分散と標準偏差（実行結果は，この順で表示される）
var(B); sd(B)

#　カウント（個数）データを擬似的に生成する準備
set.seed (12)
items <- rpois (100, lam = 5)

length (items) ; head (items) 

mean(items); median(items) # 平均値と中央値


items.cnt <- hist(items, breaks = 0:10)


items.cnt

table(items)

items.box <- boxplot (items)

items.box

summary(items) # データの概要