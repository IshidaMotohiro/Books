#　第3章　Rによるテキストマイニング

##　本書のサポートサイトからダウンロードしたファイル　hituji.zip　を解凍すると
SJISとUTF8の２種類のフォルダがあります。WindowsユーザーはSJISを、
またMacユーザーはUTF8フォルダ中にあるファイル及びフォルダ群を利用してください。

それぞれのフォルダにはdataというフォルダがあります。
これをWindowsのホームフォルダ

C:/Users/ユーザー名/Documents　

Macユーザーはホームフォルダ

/Users/ユーザ名

にコピーしたとします。


# 作業スペースの移動（第２章参照）
setwd ("C:/Users/ユーザー名/Documents/data")

#　初回実行時、やや時間がかかります


# CSVデータの読み込みと整形
dat <- read.csv("Pivot.csv", row.names = 1, skip = 3)
dat <- dat[, -ncol (dat)] # 最終列の削除
dat <- dat[-nrow (dat), ] # 最終行の削除
dat
dat[is.na (dat)] <- 0 # 欠損値の処理
dat

dat <- as.matrix(dat) #行列へ変換
dat

## RMeCabパッケージ

library(RMeCab) #パッケージのロード

RMeCabC ("すもももももももものうち") # 形態素解析

 (x <- unlist(RMeCabC("本を買いました。", 1))) 

niwatori <- RMeCabFreq("ogai_niwatori.txt") # 頻度表の作成
 head(niwatori) # 頻度表の表示（一部）

niwatori2 <- niwatori[order(niwatori$Freq, decreasing = TRUE), ]
head(niwatori2) # 冒頭部分を表示

niwatori[grep("にわとり|鶏|鳥", niwatori$Term), ]

# 形態素のみを抽出
niwatori[grep("にわとり|鶏|鳥", niwatori$Term), "Term"]


# 「て」を含む形態素の検索
head(niwatori[grep("て", niwatori$Term), ])

(x <- niwatori[grep("^て$", niwatori$Term), ])  # 助詞「が」の検索

 aggregate(x$Freq, x[1:2], sum) # 細分類を無視して，頻度を集計


# n-gram
# 空の一時ファイルを作成して、中身に英語の小説を書き込む
tmp <- tempfile(); write("英語の小説",tmp)
eigo.c <- Ngram (tmp, type = 0);eigo.c # 
eigo.w <- Ngram (tmp, type = 1, pos =　c("名詞","助詞"));eigo.w # 
eigo.p <- Ngram (tmp, type = 2); eigo.p # 
# 一時ファイル削除
unlink (tmp)


ngram <-Ngram("ogai_niwatori.txt") # n-gramの作成
head(ngram) # 冒頭部分。全角スペースとのバイグラム
tail(ngram) # 末尾部分の表示

bigram <-Ngram("ogai_niwatori.txt", type = 1) # バイグラムの作成
tail(bigram) # 末尾部分の表示


# さまざまなバイグラムの作成

bigram1 <-Ngram("omoidasu.txt", type = 1)

bigram2 <-Ngram("omoidasu.txt", type = 1, pos = "名詞")

bigram3 <-Ngram("omoidasu.txt", type = 1, pos = c ("名詞","動詞","助詞"))


head(bigram1) # デフォルトの出力

head(bigram2) # 名詞に限定したので，たとえば形容詞「暑い」が含まれない（一部で「の」をMeCabは非自立の名詞と判定している）

head(bigram3) # 抽出対象を助詞まで広げた結果


trigram <-Ngram("omoidasu.txt", type = 1, N = 3) # トライグラムの作成
head (trigram)

#　品詞情報とともにn-gramを抽出
bigram <- docDF("omoidasu.txt", type = 1, N = 2)
tail(bigram)

dm <- docMatrix("samples") # 複数ファイルから頻度行列を作成
head(dm)# 冒頭のみ表示
dm #全体を表示

dm <- dm[rownames(dm) != "[[LESS-THAN-1]]", ] # 該当行を削除
dm <- dm[rownames(dm) != "[[TOTAL-TOKENS]]", ] # 同じく削除

dm


dm <- docMatrix2("samples") # 複数ファイルから頻度行列を作成
head(dm)

dm <- docDF("samples", type = 1) # 複数ファイルから頻度行列を作成
 head(dm)


# TF-IDF
dm2 <- docMatrix2("samples", pos = c("名詞","形容詞"), weight = "tf*idf")
head(dm2)


# 正規化
dm2 <- docMatrix2("samples", pos = c("名詞","形容詞"), 
         weight = "tf*idf*norm")
head(dm2)

colSums (dm2^2) # 列こ?とに自乗した合計

bigram <- docNgram2 ("samples") #n-gramの頻度行列
head (bigram)

bigram <- docDF("samples", type = 1, N = 2)
head(bigram)

bigram <- docDF("samples", type = 1, N = 2, nDF = TRUE)
head(bigram)

koe <- read.csv("H18koe.csv") # CSVファイルの読み込み
koe [42, ]

koe2 <- docMatrixDF(koe$opinion)
koe2[300:303, 1:6] # 300-303行を表示する

koe3 <- docDF(koe, column = "opinion", type = 1) # 品詞情報を求める
koe3[300:303, 1:6]


 # コロケーションの抽出
coll <- collocate("PM/Hatoyama.txt", node = "国民", span = 3)
coll2 <- collScores(coll, node = "国民", span = 3)

head(coll2[order(coll2$T, coll2$MI, decreasing = TRUE), ])

 # T値とMI値の計算手順を確認
coll2[coll2$Term == "国民" , ] #「国民」の頻度を確認


coll2[coll2$Term == "皆さま", ] #「皆さま」の頻度を確認
tail (coll2, 2) # 総トークン数を確認


