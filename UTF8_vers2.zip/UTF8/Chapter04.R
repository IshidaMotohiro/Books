#第4章　日本語作文のテキストマイニング

##　本書のサポートサイトからダウンロードしたファイル　hituji.zip　を解凍すると
SJISとUTF8の２種類のフォルダがあります。WindowsユーザーはSJISを、
またMacユーザーはUTF8フォルダ中にあるファイル及びフォルダ群を利用してください。

それぞれのフォルダにはdataというフォルダがあります。
これをWindowsのホームフォルダ

C:/Users/ユーザー名/Documents　

Macユーザーはホームフォルダ

/Users/ユーザ名

にコピーしたとします。


# 作業スペースの移動（第２章参照）
setwd ("C:/Users/ユーザー名/Documents/data")

library(RMeCab) # 頻度集計を行う関数の準備
dm <- docDF("A", type = 1) # 頻度行列の作成

dm[grep("^(アルバイト|喫煙)$", dm$TERM), ]

dat <- matrix(c(157, 12, 3, 146), nrow = 2, byrow = TRUE) # 行列の作成
dat # データの確認
chisq.test(dat) # カイ自乗検定

dat.chi <- chisq.test(dat)
dat.chi$expected # 期待値の確認

fisher.test(dat) # フィッシャーの正確確率検定

# 細分類を無視して形態素の語形で統合
dm1 <- aggregate(dm[, -(1:3)], dm[1], sum) # dmは前段で作成済み
# 形態素列を行名に変更して削除
rownames(dm1) <- dm1[, 1] # 数値ではない列（形態素）を列名に
dm2 <- dm1[, -1]
# 列合計を計算
dmSum <- colSums(dm2)

# 単語ごとにカイ自乗値を返す関数を用意
#　本書のために用意したchiCheck.R関数を定義したスクリプトを取り込む
source("chiCheck.R") 

# apply関数は、第一引数で指定されたデータの行ごとに指定された関数（chiCheck）を実行する

dmVec <- apply(dm2, 1, chiCheck)

# ソートして，統計量上位50位までを表示

head(sort(dmVec, decreasing = T), 50)

cor(dm$ptj_all.txt, dm$smk_all.txt, method = "pearson")