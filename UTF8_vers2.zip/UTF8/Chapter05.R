#第5章　政治的談話のテキストマイニング



# p.103 表5.2の作成方法
  # MeCabのヴァージョン、あるいはOSの違いのため、本書の数値とは結果が異なることがあります


# 演説ごとにバイグラムを抽出
x <- docNgram2("data/PM2", type = 1, pos = c("名詞","形容詞"))
    # 出力の概要を確認
    nrow(x); head (x); colnames(x);ncol(x)
   #結果の一部を確認
   x[row.names(x) == "[社会-保障]",]

# 個別の単語頻度を抽出
  y  <- docDF("data/PM2", type = 1, N = 1)# 全品詞を抽出
# 出力の列名を確認(1:3列は数値ではない)
colnames (y)
#演説ごとに総語数を計算
  total <- colSums(y[, -c(1:3)])

#標準化
z <- sweep (x, 2, total, FUN = "/") #   z <- t( t(x) / total ) でも良い
z <- z * 1000

#結果の一部を確認
z[row.names(z) == "[社会-保障]",]
z[row.names(z) == "[構造-改革]",]
z[row.names(z) == "[国際-社会]",]






##　本書のサポートサイトからダウンロードしたファイル　hituji.zip　を解凍すると
SJISとUTF8の２種類のフォルダがあります。WindowsユーザーはSJISを、
またMacユーザーはUTF8フォルダ中にあるファイル及びフォルダ群を利用してください。

それぞれのフォルダにはdataというフォルダがあります。
これをWindowsのホームフォルダ

C:/Users/ユーザー名/Documents　

Macユーザーはホームフォルダ

/Users/ユーザ名

にコピーしたとします。


# 作業スペースの移動（第２章参照）
setwd ("C:/Users/ユーザー名/Documents/data")
dat <- read.delim("ShoshinHyomei.txt", row.names = 1, header = TRUE)

# tは行列を転値する
  # たとえば
  (x <- matrix (1:6, ncol = 3))
  # と
   t(x)
  # を比較してください．
summary(t(dat))

# 対応分析
library (MASS) # 対応分析を行う関数の準備
ca <- corresp(dat, nf = 2)
ca

# 解析結果のうち，行（バイグラム）の得点の冒頭を表示させる
head (ca $ rscore) 

# 固有値
ca.eig <- ca$cor^2 # 正準相関の2乗
round(ca.eig, 4) # 小数点以下4桁まで数値を丸め
# 寄与率の算出
(cntr <- round(100 * ca.eig / sum(ca.eig), 2))


# 演説の類似関係の視覚化
# 枠の描画
plot (ca$cscore[, 1], ca$cscore[, 2], type = "n", xlab = "Dim 1", ylab = "Dim 2")
# 原点を交差する破線を描画
abline(h = 0, lty = "dotted"); abline(v = 0, lty = "dotted")
# ラベルの描画
text(ca$cscore, labels = rownames(ca$cscore))

  # （スクリプトの解説）

 上のコードではplot関数内でtype = "n"を指定しています
 これを指定すると，グラフの土台は作成されますが，データ点（プロット点）は
 描かれません．デフォルトでは白丸が描かれるわけですが，この代わりに
 データ名を文字として表示したい場合などに使うテクニックです． 
 xlab=とylab=は，X軸とY軸それぞれのラベルを指定します．
 データ名は，最後にtext（）関数で描きます．

# 枠の描画
plot (ca$rscore[, 1], ca$rscore[, 2], type = "n", xlab = "Dim 1", ylab = "Dim 2")
# 
abline(h = 0, lty = "dotted"); abline(v = 0, lty = "dotted")
# ラベルの描画
text(ca$rscore, labels = rownames(ca$rscore))

# バイプロットの作成
biplot(ca)

# 第2次元の値が大きいn-gram

head(ca$rscore[order(ca$rscore[,2] , decreasing = TRUE),], 10)
## ca$rsoce すなわち列スコアに添字を指定．
## 添字では列スコアの2列目を規準に，降順decreasing = TRUEで並び替えるよう指定

# 第2次元の値が小さいn-gram
head(ca$rscore[order(ca$rscore[,2]),], 10)
## order()関数で降順を指定しなければ小さい順に表示される


# クラスター分析（キャンベラ距離，ウォード法）
d2 <- t(dat) # 行と列を入れ替え（転置）
d2 <- dist(d2, "canberra") # キャンベラ距離に変換
result <- hclust(d2, "ward") # ウォード法でクラスタリング
# 結果の表示
plot (result, hang = -1)
## hang=-1は，枝の長さをX軸と交差するまで伸ばす指定

# 高さ440に破線を引く
abline(h = 440, lty = 3)


