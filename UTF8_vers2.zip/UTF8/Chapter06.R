#第6章　対照言語データのテキストマイニング

##　本書のサポートサイトからダウンロードしたファイル　hituji.zip　を解凍すると
SJISとUTF8の２種類のフォルダがあります。WindowsユーザーはSJISを、
またMacユーザーはUTF8フォルダ中にあるファイル及びフォルダ群を利用してください。

それぞれのフォルダにはdataというフォルダがあります。
これをWindowsのホームフォルダ

C:/Users/ユーザー名/Documents　

Macユーザーはホームフォルダ

/Users/ユーザ名

にコピーしたとします。


# 作業スペースの移動（第２章参照）
setwd ("C:/Users/ユーザ名/Documents/data")

# データの読み込み
dat <- read.delim("Sushi.txt", row.names = 1, header = TRUE)
dat

# 多次元尺度法を適用
dat.cmd <- cmdscale (dist (dat), k = 2)

#　10言語の類似関係の視覚化
#　ここではプロット土台の描画のみを作成しデータは描かない((type="n")
plot (dat.cmd, type = "n")
#　プロットにデータ点を言語名（列名）で描画する
text (dat.cmd, colnames (dat))
 
# 推定値の当てはまりの良さ
cor (dist (dat), dist(dat.cmd))^2

install.packages ("ape")
library (ape)

# ユークリッド距離(デフォルト)に変換
dat.d <- dist (dat)
# 群平均法でクラスタリング
dat.hc <- hclust (dat.d, method = "average")
#　系統樹を描くためのデータ形式に変換
dat.phy <- as.phylo (dat.hc)

# 有根系統樹
plot (dat.phy, type = "c")

# 無根系統樹
plot (dat.phy, type = "u")

#　NJ法
dat.nj <- nj (dat.d)
dat.phy <- as.phylo (dat.nj)
plot (dat.phy, type = "c") # 図6.4
plot (dat.phy, type = "u") # 図6.5




# バイプロットの作成
biplot(ca)

# 第2次元の値が大きいn-gram

head(ca$rscore[order(ca$rscore[,2] , decreasing = TRUE),], 10)
## ca$rsoce すなわち列スコアに添字を指定．
## 添字では列スコアの2列目を規準に，降順decreasing = TRUEで並び替えるよう指定

# 第2次元の値が小さいn-gram
head(ca$rscore[order(ca$rscore[,2]),], 10)
## order()関数で降順を指定しなければ小さい順に表示される


# クラスター分析（キャンベラ距離，ウォード法）
d2 <- t(dat) # 行と列を入れ替え（転置）
d2 <- dist(d2, "canberra") # キャンベラ距離に変換
result <- hclust(d2, "ward") # ウォード法でクラスタリング
# 結果の表示
plot (result, hang = -1)

