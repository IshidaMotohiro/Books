#第7章　対話形式データのテキストマイニング


##　本書のサポートサイトからダウンロードしたファイル　hituji.zip　を解凍すると
SJISとUTF8の２種類のフォルダがあります。WindowsユーザーはSJISを、
またMacユーザーはUTF8フォルダ中にあるファイル及びフォルダ群を利用してください。

それぞれのフォルダにはdataというフォルダがあります。
これをWindowsのホームフォルダ

C:/Users/ユーザー名/Documents　

Macユーザーはホームフォルダ

/Users/ユーザ名

にコピーしたとします。


# 作業スペースの移動（第２章参照）
setwd ("C:/Users/ユーザー名/Documents/data")

# データの読み込み（なお，引数については第2章を参照）
dat <- read.delim("Gundam.txt", header = FALSE)
# データの確認
head(dat)


# ネットワーク分析
install.packages("igraph") # パッケージのインストール
library(igraph) # ネットワーク分析を行う関数の準備
g <- graph.data.frame(dat) # データをネットワーク化
# 描画
tkplot(g, vertex.label = V(g)$name, vertex.size = 1,
   layout = layout.fruchterman.reingold, edge.label = dat[, 3])

# 頂点の媒介中心性
(bc <- sort(betweenness(g), decreasing = TRUE))

plot (bc)


# サブグループの抽出
ebc <- edge.betweenness.community(g) # 辺の媒介中心性の計算
plot(as.dendrogram(ebc)) # 描画
