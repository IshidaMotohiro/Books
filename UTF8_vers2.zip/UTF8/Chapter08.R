#第8章　文学作品のテキストマイニング


##　本書のサポートサイトからダウンロードしたファイル　hituji.zip　を解凍すると
SJISとUTF8の２種類のフォルダがあります。WindowsユーザーはSJISを、
またMacユーザーはUTF8フォルダ中にあるファイル及びフォルダ群を利用してください。

それぞれのフォルダにはdataというフォルダがあります。
これをWindowsのホームフォルダ

C:/Users/ユーザー名/Documents　

Macユーザーはホームフォルダ

/Users/ユーザ名

にコピーしたとします。


# 作業スペースの移動（第２章参照）
setwd ("C:/Users/ユーザー名/Documents/data")

# データの読み込み（なお，引数については第2章を参照）
dat <- read.delim("Akutagawa-Dazai.txt", row.names = 1, header = TRUE)

# データの概要
summary(dat)

# クラスター分析（ユークリッド距離，最長一致法）
d <- dist(dat[, -17]) # ラベルの列を除外して，ユークリッド距離に変換
result <- hclust(d, "complete") # 最長一致法でクラスタリング
# 結果の表示
result

 # デンドログラムの描画
plot (result, hang = -1)


# 線形判別分析
library (MASS) # 判別分析を行う関数の準備
lda.model <- lda(作者 ~ ., data = dat)

lda.model # 判別モデルの確認

# 分類実験
lda.pred <- predict(lda.model, dat)
(lda.tab <- table(dat[, 17], lda.pred$class))

# 正判別率の計算（対角要素の総数を全要素数で割る）
sum(diag(lda.tab)) / sum(lda.tab)

# 線形判別分析の交差妥当化
lda.model.cv <- lda(作者 ~ ., data = dat, CV = TRUE)
# 17列目はラベルなので，数値データ列と分けて指定
(lda.tab2 <- table(dat[, 17], lda.model.cv$class)) 

# 正判別率の計算
sum(diag(lda.tab2)) / sum(lda.tab2)

# サポートベクターマシン（SVM）
install.packages(“e1071”) # パッケージのインストール
library(e1071) # SVMを実行する関数の準備
set.seed(5) #同じ結果を出すために，疑似乱数の種の設定
svm.model <- svm(作者 ~ ., data = dat, cross = 5)
summary(svm.model) # 判別モデルの概要を確認
# 正判別率の計算（予測結果は，fittedとしてアクセス）
# 17列目はラベルなので，数値データ列と分けて指定
(svm.tab <- table(dat[, 17], svm.model$fitted))
sum(diag(svm.tab)) / sum(svm.tab)

# SVMのチューニングに関するヘルプ
help(svm)
help(tune.svm)





