#第9章　ジャンル別データのテキストマイニング

##　本書のサポートサイトからダウンロードしたファイル　hituji.zip　を解凍すると
SJISとUTF8の２種類のフォルダがあります。WindowsユーザーはSJISを、
またMacユーザーはUTF8フォルダ中にあるファイル及びフォルダ群を利用してください。

それぞれのフォルダにはdataというフォルダがあります。
これをWindowsのホームフォルダ

C:/Users/ユーザー名/Documents　

Macユーザーはホームフォルダ

/Users/ユーザ名

にコピーしたとします。


# 作業スペースの移動（第２章参照）
setwd ("C:/Users/ユーザー名/Documents/data")

# データの読み込み（なお，引数については第2章を参照）
dat <- read.delim("BCCWJ.txt", header = TRUE)
# # 1行目を読み込んで，タブで区切る
# tag <- strsplit(readLines("BCCWJ.txt", 1), "\t")
# その結果を列名に指定
# colnames(dat) <- tag[[1]] 

  ## strsplit()関数は第一引数で指定された文字列を，第二引数で区切る関数です
  
  strsplit("ABC-EFG-HIJ", "-")
  # この場合はハイフンで文字列を区切ります（ハイフンは残しません）
  # 上のコードでは”￥ｔ”と指定していますが（円マークはRではバックスラッシュとして表示されます）
  # これはタブ（複数の半角スペース相当の空白）を意味します．つまり"BCCWJ.txt"の1行目を
  # 文字列として扱い，タブごとに区切るという意味です


# データの概要
summary(dat)


# 学習データと評価データを作成
n <- seq(1, nrow(dat), by = 2) # 奇数のベクトルを生成
dat.train <- dat[n, ] # 奇数行のデータを抽出
dat.test <- dat[-n, ] # 偶数行のデータを抽出

  # seq(）は指定された間隔の数列を作成する関数です
   seq(2,10,2) #　２から１０までを２つ間隔で

# ナイーブベイズ
# install.packages("e1071") # パッケージのインストール
library(e1071) # ナイーブベイズを行う関数の準備
nb.model <- naiveBayes(ジャンル ~ ., data = dat.train)
nb.model # 判別モデルの確認

# 分類実験
nb.pred <- predict(nb.model, dat.test)
# 13列目はラベルなので，数値データ列と分けて指定
(nb.tab <- table(dat.test[, 8], nb.pred))

# 正判別率の計算（対角要素の総数を全要素数で割る）
sum(diag(nb.tab)) / sum(nb.tab)


# k近傍法
install.packages("class") # パッケージのインストール
library(class) # k近傍法を行う関数の準備

knn.model <- knn(dat.train[, -8], dat.test[, -8], dat.train[, 8], k = 3)

#　作成した判別モデル（knn.model）の情報は，以下のとおりです。

knn.model

# 分類実験
# 8列目はラベルなので，数値データ列と分けて指定
(knn.tab <- table(dat.test[, 8], knn.model))

# 正判別率の計算（対角要素の総数を全要素数で割る）
sum(diag(knn.tab)) / sum(knn.tab)


# バギング

# install.packages("adabag") # パッケージのインストール
library(adabag) # バギングを行う関数の準備

ncol (dat)

# データの読み込み（なお，引数については第2章を参照）
set.seed (5)
bag.model <- bagging(ジャンル ~ ., data = dat.train)

bag.model$importance # それぞれの説明変数の重要度

bag.pred <- predict(bag.model, newdata = dat.test)
(bag.tab <- table(dat.test[, 8], bag.pred$class))


 # 正判別率の計算（対角要素の総数を全要素数で割る）
sum(diag(bag.tab)) / sum(bag.tab)


