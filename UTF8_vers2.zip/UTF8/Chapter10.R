#第9章　ジャンル別データのテキストマイニング


##　本書のサポートサイトからダウンロードしたファイル　hituji.zip　を解凍すると
SJISとUTF8の２種類のフォルダがあります。WindowsユーザーはSJISを、
またMacユーザーはUTF8フォルダ中にあるファイル及びフォルダ群を利用してください。

それぞれのフォルダにはdataというフォルダがあります。
これをWindowsのホームフォルダ

C:/Users/ユーザー名/Documents　

Macユーザーはホームフォルダ

/Users/ユーザ名

にコピーしたとします。


# 作業スペースの移動（第２章参照）
setwd ("C:/Users/ユーザー名/Documents/data")

# データの読み込み（なお，引数については第2章を参照）
dat <- read.delim("kinoko.txt", header = TRUE)
# データの概要
summary(dat)

# 学習データと評価データを作成
set.seed(5) #同じ結果を出すために，疑似乱数の種の設定
n <- sample(1:258, 158) # 1から258までの数値から158個の数値を抽出
dat.train <- dat[n, ] # 乱数で指定された番号のデータを訓練データに
dat.test <- dat[-n, ] # その残りを評価データに

 # 決定木
install.packages("mvpart") # パッケージのインストール

library(mvpart) # 決定木を行う関数の準備
set.seed(5) #同じ結果を出すために，疑似乱数の種の設定
rp.model <- rpart(アクセント ~ ., data = dat.train)

print(rp.model, digit = 1) # 判別モデルの確認

par(xpd = NA)
# 木の視覚化
plot(rp.model, minbranch = 3) # 引数minbranchは枝の長さを調整
text(rp.model, use.n = TRUE)

plotcp (rp.model)

# 木の剪定（より良い判別モデルの作成）
rp.model.pr <- prune(rp.model, cp = 0.082)
# 剪定した木の視覚化
par(xpd = NA) #無駄な余白を消す処理（ウィンドウ全体を使う）
plot(rp.model.pr, minbranch = 2) # 引数minbranchは枝の長さを調整
text(rp.model.pr, use.n = TRUE)

# 分類実験
rp.pred <- predict(rp.model.pr, dat.test, type = "class")
# 4列目はラベルなので，数値データ列と分けて指定
(rp.tab <- table(dat.test[, 4], rp.pred))

# 正判別率の計算（対角要素の総数を全要素数で割る）
sum(diag(rp.tab)) / sum(rp.tab) 

# ランダムフォレスト
install.packages("randomForest") # パッケージのインストール

library(randomForest) # ランダムフォレストを行う関数の準備
set.seed(5) # 疑似乱数の種の設定
rf.model <- randomForest(アクセント ~ ., ntree = 1000, mtry = 2,
   proximity = TRUE, data = dat.train)

rf.model

# 説明変数の寄与度
varImpPlot(rf.model)


# 多次元尺度法
MDSplot(rf.model, dat.train$アクセント,
   pch = as.numeric(dat.train$アクセント))

# 分類実験
rf.pred <- predict(rf.model, dat.test)
# 4列目はラベルなので，数値データ列と分けて指定
(rf.tab <- table(dat.test[, 4], rf.pred))

sum (diag (rf.tab)) / sum (rf.tab)





