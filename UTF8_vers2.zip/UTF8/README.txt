 2013 年 10 月 21 日

石田 基広、 小林 雄一郎 著『Rで学ぶ日本語テキストマイニング』 ひつじ書房 (2013/10/30)


* 本書の付録ファイル

SJIS.zip   （Windows 用）
UTF8.zip   （Mac OS X 用）

利用しているパソコンごとに適切なファイルをこのページ下のリストからダウンロードしてください．
ダウンロードは右端の↓ を押すと．保存先を尋ねられますので，適当なフォルダを選んでください．

* Rのインストール


http://cran.md.tsukuba.ac.jp/ あるいは http://cran.ism.ac.jp/
にアクセスし，Download and Install R 欄から，利用しているパソコンごとに用意されたリンクをクリックします．
リンク先のファイル （Download R 3.0.2 for Windows あるいは R-3.0.2.pkg） をダウンロードし，ダブルクリックで標準設定のままインストールを行います．

* Rの環境設定

グラフィックスなどで日本語フォントが正しく表示されるようにパソコンごとに環境設定ファイルを用意する必要があります．
Rを起動して R console というウィンドウ内部で ＞ の右に，以下のように入力してEnterキーを押してください．

download.file("http://web.ias.tokushima-u.ac.jp/linguistik/.Rprofile",dest="~/.Rprofile")

この操作により，本書の付録として含まれる dot.Rprofile.txt がユーザーのホームフォルダに .Rrofile として保存されます
（すでに．Profileが存在する場合は上書きされます）．

これはRインストール後に１度だけ実行して下さい．環境設定ファイルをダウンロード後，いったんRを終了させます．
「作業スペースを保存する」か尋ねられますが，常に「いいえ」を選んでください．
次回の起動時から，グラフィックス用の日本語設定などが有効になります．



* MeCab のインストール方法

 --  Windows (32/64 bit) の場合
  MeCab-0.996.exe を http://code.google.com/p/mecab/downloads/list からダウンロードしてインストールします．

 -- Mac (Mountain Lion / Lion) の場合

 以下の手順でソースからMeCabをコンパイルしてください。
 
 はじめに Xcode を入手してインストールしておきます．
    ただしXcode4.3以降では追加でコマンドラインツールをインストールする必要があります．Xcodeにおいて［Xcode］メニューの ［Preferences...］を選んだ後に［Downloads］をクリックし［Components］タブの［Command Line Tools］の右側にある［Install］ボタンをクリックします。
  
http://code.google.com/p/mecab/downloads/list から mecab-0.996.tar.gz  を「ダウンロード」フォルダにダウンロードします．

ターミナルを起動して、以下のように打ち込みます
 #  $ wget http://mecab.googlecode.com/files/mecab-0.996.tar.gz
 $ cd Downloads
 $ tar zxf mecab-0.996.tar.gz
 $ cd mecab-0.996
 $ ./configure --with-charset="utf8"
 $ make
 $ sudo make install

 同じくhttp://code.google.com/p/mecab/downloads/list から辞書 mecab-ipadic-2.7.0-20070801.tar.gz をダウンロードして、インストールします．
#   $ wget http://mecab.googlecode.com/files/mecab-ipadic-2.7.0-20070801.tar.gz
 $ cd Downloads
 $ tar zxf mecab-ipadic-2.7.0-20070801.tar.gz
 $ cd mecab-ipadic-2.7.0-20070801
 $ ./configure --with-charset="utf-8"
 $ make
 $ sudo make install

 -- Linux の場合
   https://sites.google.com/site/rmecab/home/rmecab_0-9993 を参照ください． 

* RMeCab のインストール

Rを起動して以下を実行します．Windows版の場合は，R i386 あるいは R x64 のいずれかで実行します．


install.packages ("RMeCab", repos = "http://rmecab.jp/R")

なお RMeCabのインストール方法は，本書の執筆後に変更されています．ただし本書の説明通りにインストールを実行されても問題もありません．
またインストールの詳細は，https://sites.google.com/site/rmecab/home/rmecab_0-9993 を参照ください．


以下をR Console で実行して，インストールが成功したかを試します．

library (RMeCab)
RMeCabC("すもももももももものうち")


library(RMeCab)でロードに失敗するときは，以下の方法で再インストールを行なってださい．

install.packages ("RMeCab", repos = "http://rmecab.jp/R", type = "source")





*  謝辞
 MeCab を開発された工藤拓さんはじめ，関係者の方々に感謝を申しあげます．
