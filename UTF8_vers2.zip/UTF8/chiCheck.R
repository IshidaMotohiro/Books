

# カイ自乗値を返す関数
chiCheck <- function (x){
  tmp <- rbind(x, dmSum - x)
  tmp <- chisq.test (tmp) $statistic
  names (tmp) <- rownames (x)
  tmp
}
